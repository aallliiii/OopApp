﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class SpecifiedWorkout
    {
        private int? WorkoutId;
        private int? TrainerId;
        private string Monday;
        private string Tuesday;
        private string Wednesday;
        private string Thursday;
        private string Friday;
        private string Saturday;

        public SpecifiedWorkout (int workOutId, int trainerId, string monday, string tuesday, string wednesday, string thursday, string friday, string saturday)
        {
            WorkoutId = workOutId;
            TrainerId = trainerId;
            Monday = monday;
            Tuesday = tuesday;
            Wednesday = wednesday;
            Thursday = thursday;
            Friday = friday;
            Saturday = saturday;
        }
        public SpecifiedWorkout(string monday, string tuesday, string wednesday, string thursday, string friday, string saturday)
        {
            WorkoutId = null;
            TrainerId = null;
            Monday = monday;
            Tuesday = tuesday;
            Wednesday = wednesday;
            Thursday = thursday;
            Friday = friday;
            Saturday = saturday;
        }
        public int? MyWorkoutId { get=> WorkoutId; set=> WorkoutId = value; }
        public int? MyTrainer { get=> TrainerId; set => TrainerId = value; }
        public string MyMonday { get => Monday; set => Monday = value; }

        public string MyTuesday { get => Tuesday; set => Tuesday = value; }

        public string MyWednesday { get => Wednesday; set => Wednesday = value; }

        public string MyThursday { get => Thursday;set => Thursday = value; }

        public string MyFriday { get => Friday; set => Friday = value; }

        public string MySaturday { get => Saturday; set => Saturday = value; }
    }
}
