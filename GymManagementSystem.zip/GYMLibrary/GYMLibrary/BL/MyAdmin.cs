﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class MyAdmin : MyUser
    {
        public MyAdmin() { }

        List<Employees> Employees;  
        List<MyMember> Members;
        
        public MyAdmin(string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email, int Role) :
            base(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role)
        {
            Employees = new List<Employees>(); 
            Members = new List<MyMember>();
        }
        

        public MyAdmin(string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email) :
            base(UserName, Password, FirstName, LastName, PhoneNumber, Email)
        {

        }


    }
}
