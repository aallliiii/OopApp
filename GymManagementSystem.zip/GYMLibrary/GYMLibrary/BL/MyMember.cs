﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class MyMember : MyUser
    {
        List<Performance> performances;
        Payments payments;
        public MyMember () { }
        public MyMember (string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email, int Role) :
             base(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role)
        {
            performances = new List<Performance> ();
            payments = new Payments();
        }

        public MyMember (string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email) :
            base(UserName, Password, FirstName, LastName, PhoneNumber, Email)
        {

        }
    }
}
