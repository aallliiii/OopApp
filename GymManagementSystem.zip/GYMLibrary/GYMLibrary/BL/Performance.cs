﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class Performance
    {
        int? PerformanceId;
        int? MemberId;
        DateTime? Date;
        int WorkoutDuration;
        int Calories;
       
        int Distance;
        int HeartBeat;

        public Performance(int performanceId, int memberId, DateTime date, int workoutDuration, int calories,  int distance, int heartBeat)
        {
            PerformanceId = performanceId;
            MemberId = memberId;
            Date = date;
            WorkoutDuration = workoutDuration;
            Calories = calories;
            
            Distance = distance;
            HeartBeat = heartBeat;
        }

        public Performance(int workoutDuration, int calories, int distance, int heartBeat)
        {
            PerformanceId = null;
            MemberId = null;
            Date = null;
            WorkoutDuration = workoutDuration;
            Calories = calories;

            Distance = distance;
            HeartBeat = heartBeat;
        }

        public int? MyPerformanceId { get =>  PerformanceId; set => PerformanceId = value; }
        public int? MyMemberId { get => MemberId; set => MemberId = value; }
        public DateTime? MyDate { get => Date; set => Date = value; }
        public int MyDuration { get => WorkoutDuration; set => WorkoutDuration = value; }
        public int MyDistance { get => Distance; set => Distance = value; }

        public int MyCalories { get => Calories; set => Calories = value; }

        public int MyHeartBeat { get => HeartBeat; set => HeartBeat = value; }

    }
}
