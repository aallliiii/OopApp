﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class Employees
    {
        private int? EmployeeId;
        private string FirstName;
        private string LastName;
        private string Designation;
        private string Salary;
        private Salary MySalaryClass;
        public Employees(string firstName, string lastName, string designation, string salary)
        {
            EmployeeId = null;
            FirstName = firstName;
            LastName = lastName;
            Designation = designation;
            Salary = salary;
            MySalaryClass = new Salary();
        }

        public Employees(int employeeId, string firstName, string lastName, string designation, string salary)
        {
            EmployeeId = employeeId;
            FirstName = firstName;
            LastName = lastName;
            Designation = designation;
            Salary = salary;
        }

        public int? MyEmployeeId { get => EmployeeId; set => EmployeeId = value; }
        public string MyFirstName { get => FirstName; set => FirstName = value; }
        public string MyLastName { get => LastName; set => LastName = value; }

        public string MyDesignation { get => Designation; set => Designation = value; }

        public string MySalary { get => Salary; set => Salary = value; }
    }
}
