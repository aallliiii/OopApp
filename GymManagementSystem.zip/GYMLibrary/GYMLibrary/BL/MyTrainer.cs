﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class MyTrainer : MyUser
    {
        private List<Session> sessions;
        private List<SpecifiedWorkout> workouts;
        public MyTrainer() { }
        public MyTrainer (string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email, int Role) :
            base(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role)
        {
            sessions = new List<Session>(); 
            workouts = new List<SpecifiedWorkout>();
        }

        public MyTrainer (string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email) :
            base(UserName, Password, FirstName, LastName, PhoneNumber, Email)
        {

        }

        public List<Session> MySession { get => sessions; set => sessions = value; }
        public List<SpecifiedWorkout> Workouts { get => workouts; set => workouts = value; }


    }
}
