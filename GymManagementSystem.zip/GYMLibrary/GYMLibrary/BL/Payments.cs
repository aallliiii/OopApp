﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class Payments
    {
        private int FeesId;
        private int MemberId;
        private int Months;
        private int Amount;
        private string PaymentMethod;
        DateTime Date;

        public Payments() { }
        public Payments(int feesId, int memberId, int months, int amount, string paymentMethod, DateTime date)
        {
            FeesId = feesId;
            MemberId = memberId;
            Months = months;
            Amount = amount;
            PaymentMethod = paymentMethod;
            Date = date;
        }

        public int MyFeesId { get => FeesId; set => FeesId = value; }
        public int MyMemberId { get => MemberId; set => MemberId = value; }
        public int MyMonths { get => Months; set => Months = value; }
        public int MyAmount { get => Amount; set => Amount = value; }
        public string MyPaymentMethod { get => PaymentMethod; set => PaymentMethod = value; }
        public DateTime MyDate { get => Date; set => Date = value; }

    }
}
