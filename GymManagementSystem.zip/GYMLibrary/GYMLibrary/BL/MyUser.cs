﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class MyUser
    {
        protected string UserName;
        protected string Password;
        protected string FirstName;
        protected string LastName;
        protected string PhoneNumber;
        protected string Email;
        protected int Role;

        public string MyUserName { get => UserName; set => UserName = value; }
        public string MyPassword { get => Password; set => Password = value; }
        public string MyFirstName { get => FirstName; set => FirstName = value; }
        public string MyLastName { get => LastName; set => LastName = value; }
        public string MyEmail { get => Email; set => Email = value; }
        public string MyPhoneNumber { get => PhoneNumber; set => PhoneNumber = value; }
        public int MyRole { get => Role; set => Role = value; }

        public MyUser() { }
        public MyUser(string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email, int Role)
        {
            this.UserName = UserName;
            this.Password = Password;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;
            this.Role = Role;
        }

        public MyUser(string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email)
        {
            this.UserName = UserName;
            this.Password = Password;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;

        }

        public MyUser(string UserName, string Password)
        {
            this.UserName = UserName;
            this.Password = Password;
        }

        


    }
}
