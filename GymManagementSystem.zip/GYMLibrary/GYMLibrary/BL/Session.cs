﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class Session
    {
        private int? SessionId;
        private int? TrainerId;
        private DateTime MyDate;
        private TimeSpan StartTime;
        private TimeSpan EndTime;

        public Session(int sessionId, int trainerId, DateTime myDate, TimeSpan startTime, TimeSpan endTime)
        {
            SessionId = sessionId;
            TrainerId = trainerId;
            MyDate = myDate;
            StartTime = startTime;
            EndTime = endTime;
        }

        public Session(DateTime myDate, TimeSpan startTime, TimeSpan endTime)
        {
            SessionId = null;
            TrainerId = null;
            MyDate = myDate;
            StartTime = startTime;
            EndTime = endTime;
        }

        public int? MySessionId { get => SessionId; set => SessionId = value; }
        public int? MyTrainerId { get => TrainerId; set => TrainerId = value; }
        public DateTime Date { get => MyDate; set => MyDate = value; }
        public TimeSpan MyStartTime { get => StartTime; set => StartTime = value; }
        public TimeSpan MyEndTime {  get => EndTime; set => EndTime = value; }

    }
}
