﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYMLibrary.BL
{
    public class Salary
    {
        private int SalaryId;
        private int EmployeeId;
        private string Date;
        private string PaymentMethod;

        public Salary() { }
        public Salary (int salaryId, int employeeId, string date, string paymentMethod)
        {
            SalaryId = salaryId;
            EmployeeId = employeeId;
            Date = date;
            PaymentMethod = paymentMethod;
        }

        public int MySalaryId { get => SalaryId; set => SalaryId = value; }

        public int MyEmployeeId { get => EmployeeId; set => EmployeeId = value; }

        public string MyDate { get => Date; set => Date = value; }

        public string MyPaymentMethod { get => PaymentMethod; set => PaymentMethod = value; }
    }
}
