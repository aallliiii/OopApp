﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;

namespace GYMLibrary.Utilities
{
    public interface ISignInUp
    {
        bool SignUp(MyUser User);
        MyUser Login (MyUser User);

        bool IsUserNameValid(string username);

        List<string> CategoryType();

        List<string> CategoryTypeMember();
    }
}
