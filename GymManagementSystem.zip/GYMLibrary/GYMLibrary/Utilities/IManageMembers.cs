﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;

namespace GYMLibrary.DL
{
    public interface IManageMembers
    {
        bool UpdateMember(string OldUserName, MyMember myMember);

        
        List<MyMember> ViewMember();

        

        bool DeleteMember(string UserName);

        List<string> GetUsernameList();

        bool CheckMemberUsername(string Username);



    }
}
