﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;

namespace GYMLibrary.Utilities
{
    internal interface ISessions
    {
        bool AddSessions (Session session, string UserName);

        List<Session> GetSessions (string UserName);

        bool UpdateSessions(Session session, int SessionId);

        bool DeleteSessions (int SessionId);  
    }
}
