﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;

namespace GYMLibrary.Utilities
{
    internal interface IWorkout
    {
        bool AddSpecifiedWorkout(string UserName,SpecifiedWorkout specifiedWorkout);

        List<SpecifiedWorkout> GetSpecifiedWorkouts(string UserName);

        bool DeleteWorkout(int WorkoutId);
    }
}
