﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;
using GYMLibrary.DL;


namespace GYMLibrary.Utilities
{
    public class ObjectHandler
    {

        private static MyUser myUser = new MyUser();

        private static MyUserDL myUserDL = new MyUserDL();

        private static AdminDL adminDL = new AdminDL();

        private static TrainerDL trainerDL = new TrainerDL();

        private static MemberDL memberDL = new MemberDL();

        private static MyTrainer trainer = new MyTrainer(); 

        private static AdminFH adminFH = new AdminFH();

        private static MyUserFH myUserFH = new MyUserFH();

        private static ISignInUp signInUp = new MyUserDL();
        //private static ISignInUp signInUp = new MyUserFH();

        private static IManageMembers manageMembers = new AdminDL();
        //private static IManageMembers manageMembers = new AdminFH();

        public static MyUser GetMyUser()
        {
            return myUser;
        }

        public static MyUserDL GetMyUserDL()
        {
            return myUserDL;
        }

        public static AdminDL GetAdminDL()
        {
            return adminDL;
        }

        public static TrainerDL GetTrainerDL()
        {
            return trainerDL;
        }

        public static MemberDL GetMemberDL()
        {
            return memberDL;    
        }

        public static MyTrainer GetTrainer()
        {
            return trainer;
        }

        public static AdminFH GetAdminFH()
        {
            return adminFH;
        }

        public static MyUserFH GetMyUserFH()
        {
            return myUserFH;
        }

        public static ISignInUp GetSignInUp ()
        {
            return signInUp;
        }
        public static IManageMembers ManageMembers ()
        {
            return manageMembers;
        }
    }
}
