﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;

namespace GYMLibrary.DL
{
    internal interface IManageEmployees
    {
        bool AddEmployees(Employees employee, string Username);
        List<Employees> ViewEmployee(string id);

        List<Employees> ViewEmployee();

        bool UpdateEmployees(Employees employee);

        bool DeleteEmployees(int id);

        List<Salary> ViewSalary();

        bool AddSalary(int Id, string Method);
    }
}
