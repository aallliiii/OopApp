﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics.SymbolStore;
using System.IO;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using GYMLibrary.BL;

namespace GYMLibrary.DL
{
    public class AdminFH : MyUserFH, IManageMembers
    {
        
        public bool DeleteMember(string Username)
        {
            string[] filelines = File.ReadAllLines(MyUserFH.filePath);

            List<string> members = new List<string>();

            bool MyMemberFound = false;

            foreach (string line in filelines)
            {
                string[] SplittedLines = line.Split(',');

                if (SplittedLines.Length > 0 && SplittedLines[0] == Username && SplittedLines[6] == 3.ToString())
                {
                    MyMemberFound = true;
                }
                else
                {
                    members.Add(line);
                }
            }

            if (MyMemberFound)
            {
                File.WriteAllLines(MyUserFH.filePath, members);
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<MyMember> ViewMember()
        {
            string Record;

            List<MyMember> Members = new List<MyMember>();

            StreamReader f = new StreamReader(MyUserFH.filePath);

            if (File.Exists(MyUserFH.filePath))
            {
                while ((Record = f.ReadLine()) != null)
                {
                    string[] SplittedLines = Record.Split(',');
                    if (SplittedLines.Length > 0 && SplittedLines[6] == 3.ToString())
                    {
                        string Username = SplittedLines[0];
                        string Password = SplittedLines[1];
                        string FirstName = SplittedLines[2];
                        string LastName = SplittedLines[3];
                        string PhoneNumber = SplittedLines[4];
                        string Email = SplittedLines[5];
                        int Role = int.Parse(SplittedLines[6]);

                        MyMember myMember = new MyMember(Username, Password, FirstName, LastName, PhoneNumber, Email, Role);

                        Members.Add(myMember);
                    }
                }
                f.Close();
            }
            return Members;
        }

        public bool UpdateMember(string Username, MyMember myMember)
        {
            string[] lines = File.ReadAllLines(MyUserFH.filePath);
            List<string> UpdatedLines = new List<string>();
            bool MemberUpdated = false;

            foreach (string line in lines)
            {
                string[] SplittedLines = line.Split(',');
                if (SplittedLines.Length > 0 && SplittedLines[6] == 3.ToString() && SplittedLines[0] == Username)
                {
                    SplittedLines[0] = myMember.MyUserName;
                    SplittedLines[1] = myMember.MyPassword;
                    SplittedLines[2] = myMember.MyFirstName;
                    SplittedLines[3] = myMember.MyLastName;
                    SplittedLines[4] = myMember.MyPhoneNumber;
                    SplittedLines[5] = myMember.MyEmail;
                    SplittedLines[6] = 3.ToString();

                    string Updated = string.Join(",", SplittedLines);
                    UpdatedLines.Add(Updated);
                    MemberUpdated = true;
                }
                else
                {
                    UpdatedLines.Add(line);
                }
            }

            if (MemberUpdated)
            {
                File.WriteAllLines(MyUserFH.filePath, UpdatedLines);
                return true;
            }
            else { return false; }
        }

        public List<string> GetUsernameList()
        {
            List<string> usernames = new List<string>();


            // Open the file for reading
            using (StreamReader reader = new StreamReader(MyUserFH.filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    // Split the line by commas
                    string[] entities = line.Split(',');

                    // Check if there are at least 2 entities and role is 3
                    if (entities.Length >= 7 && entities[6] == "3")
                    {
                        // Add the username (first entity) to the list
                        usernames.Add(entities[0].Trim());
                    }
                }
            }



            return usernames;
        }

        public bool CheckMemberUsername(string Username)
        {

            string[] filelines = File.ReadAllLines(MyUserFH.filePath);

            

            bool MyMemberFound = false;

            foreach (string line in filelines)
            {
                string[] SplittedLines = line.Split(',');

                if (SplittedLines.Length > 0 && SplittedLines[0] == Username && SplittedLines[6] == 3.ToString())
                {
                    MyMemberFound = true;
                }
                
            }

            if (MyMemberFound)
            {
                
                return true;
            }
            else
            {
                return false;
            }


        }
    }
}
