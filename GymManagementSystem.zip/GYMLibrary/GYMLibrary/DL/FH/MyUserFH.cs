﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYMLibrary.DL
{
    public class MyUserFH : ISignInUp
    {
        public static string filePath = "E:\\Semester 2\\oop lab\\opp project final\\GYMLibrary\\GYMLibrary\\bin\\Debug\\MyUser.txt";
        public static string CategoryPath = "E:\\Semester 2\\oop lab\\opp project final\\GYMLibrary\\GYMLibrary\\bin\\Debug\\Category.txt";

        public bool SignUp(MyUser user)
        {

            StreamWriter file = new StreamWriter(filePath, true);
            file.WriteLine(user.MyUserName + "," + user.MyPassword + "," + user.MyFirstName + "," + user.MyLastName + "," + user.MyPhoneNumber + "," + user.MyEmail + "," + user.MyRole);
            file.Flush();
            file.Close();
            return true;
        }

        public MyUser Login(MyUser user)
        {


            // Check if the file exists
            if (!File.Exists(filePath))
            {
                return null;
            }

            StreamReader SR = new StreamReader(filePath);
            string line;
            while ((line = SR.ReadLine()) != null)
            {
                string[] parts = line.Split(',');
                if (parts.Length >= 7 && parts[0] == user.MyUserName && parts[1] == user.MyPassword)
                {
                    string UserName = parts[0];
                    string Password = parts[1];
                    string FirstName = parts[2];
                    string LastName = parts[3];
                    string PhoneNumber = parts[4];
                    string Email = parts[5];
                    int Role = int.Parse(parts[6]);

                    MyUser myUser = new MyUser(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role);
                    
                    SR.Close(); 
                    return myUser;
                }
            }
            SR.Close(); 

            return null;
        }

        public List<string> CategoryType()
        {
            List<string> categories = new List<string>();
            using (StreamReader reader = new StreamReader(CategoryPath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    // Split the line by commas
                    string[] entities = line.Split(',');


                    // Add the username (first entity) to the list
                    categories.Add(entities[0].Trim());
                    categories.Add(entities[1].Trim());

                }
            }
            return categories;


        }

        public List<string> CategoryTypeMember()
        {
            List<string> categories = new List<string>();
            using (StreamReader reader = new StreamReader(MyUserFH.CategoryPath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    // Split the line by commas
                    string[] entities = line.Split(',');


                    // Add the username (first entity) to the list
                    categories.Add(entities[2].Trim());


                }
            }
            return categories;


        }

        public bool IsUserNameValid(string username)
        {

            if (!File.Exists(filePath))
            {

                throw new FileNotFoundException($"File {filePath} not found.");
            }


            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {

                string[] parts = line.Split(',');

                // Check if the username matches
                if (parts.Length >= 7 && parts[0].Trim().Equals(username.Trim(), StringComparison.OrdinalIgnoreCase))
                {

                    return false;
                }
            }


            return true;
        }

    }
}
