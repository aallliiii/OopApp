﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;
using System.Data.SqlClient;
using System.Globalization;
using System.Net.Http.Headers;
using System.IO;
using GYMLibrary.Utilities;

namespace GYMLibrary.DL
{
    public class MyUserDL : ISignInUp
    {
        public static string ConnectionString = "Data Source=DESKTOP-4QQAIDQ\\SQLEXPRESS;Initial Catalog=GymManagementSystem;Integrated Security=True;";





        public bool IsUserNameValid(string username)
        {

            int id = 0;
            string Command = "select id from MyUser where UserName=@UserName";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@UserName", username);
            id = Convert.ToInt32(cmd.ExecuteScalar());
            if (id == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public MyUser Login(MyUser myUser)
        {

            string Command = "select * from myUser where UserName=@UserName and Password=@Password";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@UserName", myUser.MyUserName);
            cmd.Parameters.AddWithValue("@Password", myUser.MyPassword);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                myUser = new MyUser(reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetString(6), reader.GetInt32(7));
                con.Close();
                return myUser;
            }
            else
            {
                con.Close();
                return null;
            }
        }

        public bool SignUp(MyUser myUser)
        {
            string Command = "insert into MyUser values (@UserName,@Password,@FirstName,@LastName,@PhoneNumber,@Email,@Role)";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@UserName", myUser.MyUserName);
            cmd.Parameters.AddWithValue("@Password", myUser.MyPassword);
            cmd.Parameters.AddWithValue("@FirstName", myUser.MyFirstName);
            cmd.Parameters.AddWithValue("@LastName", myUser.MyLastName);
            cmd.Parameters.AddWithValue("@PhoneNumber", myUser.MyPhoneNumber);
            cmd.Parameters.AddWithValue("@Email", myUser.MyEmail);
            cmd.Parameters.AddWithValue("@Role", myUser.MyRole);
            int rows = cmd.ExecuteNonQuery();
            con.Close();
            if (rows > 0)
            {

                return true;
            }
            else
            {

                return false;
            }

        }



        public bool IsAdmin(MyUser myUser)
        {

            if (myUser.MyRole == 1)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        public bool IsTrainer(MyUser myUser)
        {
            if (myUser.MyRole == 2)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        public bool IsMember(MyUser myUser)
        {
            if (myUser.MyRole == 3)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        public bool MyUpdate(string MyUserName, MyUser myUser)
        {
            try
            {
                string Command = "update myuser set UserName=@UserName, Password=@Password, FirstName=@FirstName, LastName=@LastName, PhoneNumber=@PhoneNumber, Email=@Email where id=@id";
                string IdCommand = "select id from myuser where username=@username";
                int Id;
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand id = new SqlCommand(IdCommand, con);
                id.Parameters.AddWithValue("@userName", MyUserName);
                Id = Convert.ToInt32(id.ExecuteScalar());
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@UserName", myUser.MyUserName);
                cmd.Parameters.AddWithValue("@Password", myUser.MyPassword);
                cmd.Parameters.AddWithValue("@FirstName", myUser.MyFirstName);
                cmd.Parameters.AddWithValue("@LastName", myUser.MyLastName);
                cmd.Parameters.AddWithValue("@PhoneNumber", myUser.MyPhoneNumber);
                cmd.Parameters.AddWithValue("@Email", myUser.MyEmail);
                cmd.Parameters.AddWithValue("@Id", Id);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }


        }


        public List<string> CategoryType()
        {
            string query = "SELECT category FROM UserType where id != 3";

            List<string> categories = new List<string>();

            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);




            SqlDataReader reader = command.ExecuteReader();



            while (reader.Read())
            {
                categories.Add(reader.GetString(0));
            }


            reader.Close();
            connection.Close();
            return categories;
        }

        public List<string> CategoryTypeMember()
        {
            string query = "SELECT category FROM UserType where id = 3";

            List<string> categories = new List<string>();

            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);




            SqlDataReader reader = command.ExecuteReader();



            while (reader.Read())
            {
                categories.Add(reader.GetString(0));
            }


            reader.Close();
            connection.Close();
            return categories;
        }
    }
}
