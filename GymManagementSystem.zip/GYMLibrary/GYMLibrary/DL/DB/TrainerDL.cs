﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYMLibrary.DL
{
    public class TrainerDL : MyUserDL, ISessions, IWorkout
    {
        public bool AddSessions(Session session, string UserName)
        {

            try
            {
                int TrainerId;
                string Command = "insert into sessions values (@TrainerId, @Date, @StartTime, @EndTime)";
                string CommandId = "select id from myUser where userName=@userName";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand Id = new SqlCommand(CommandId, con);
                Id.Parameters.AddWithValue("@userName", UserName);
                TrainerId = Convert.ToInt32(Id.ExecuteScalar());

                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@TrainerId", TrainerId);
                cmd.Parameters.AddWithValue("@Date", session.Date);
                cmd.Parameters.AddWithValue("@StartTime", session.MyStartTime);
                cmd.Parameters.AddWithValue("@EndTime", session.MyEndTime);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Session> GetSessions(string UserName)
        {

            List<Session> MySessions = new List<Session>();
            
            string Command = "select * from sessions join myuser on sessions.trainerid = myuser.id where username=@username";
           
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            

            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@username", UserName);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int SessionId = reader.GetInt32(reader.GetOrdinal("SessionId"));
                int MyTrainerId = reader.GetInt32(reader.GetOrdinal("TrainerId"));
                DateTime MyDate = reader.GetDateTime(2);
                TimeSpan StartTime = reader.GetTimeSpan(3);
                TimeSpan EndTime = reader.GetTimeSpan(4);

                MySessions.Add(new Session(SessionId, MyTrainerId, MyDate, StartTime, EndTime));
            }
            reader.Close();
            con.Close();
            return MySessions;


        }

        public bool UpdateSessions(Session session, int SessionId)
        {
            try
            {
                string Command = "update sessions set Date=@Date, StartTime=@StartTime, EndTime=@EndTime where SessionId=@SessionId";

                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand(Command, con);

                cmd.Parameters.AddWithValue("@Date", session.Date);
                cmd.Parameters.AddWithValue("@StartTime", session.MyStartTime);
                cmd.Parameters.AddWithValue("@EndTime", session.MyEndTime);
                cmd.Parameters.AddWithValue("@SessionId", SessionId);

                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }

        }

        public bool DeleteSessions(int SessionId)
        {
            try
            {
                string Command = "delete from sessions where sessionid=@sessionid";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@SessionId", SessionId);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool AddSpecifiedWorkout(string UserName, SpecifiedWorkout specifiedWorkout)
        {
            try
            {
                string Command = "insert into SpecialWorkout values (@TrainerId, @Monday, @Tuesday, @Wednesday, @Thursday, @Friday, @Saturday)";
                string IdCommand = "select id from myuser where userName=@userName";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand ID = new SqlCommand(IdCommand, con);
                ID.Parameters.AddWithValue("@userName", UserName);
                int TrainerId = Convert.ToInt32(ID.ExecuteScalar());
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@TrainerId", TrainerId);
                cmd.Parameters.AddWithValue("@Monday", specifiedWorkout.MyMonday);
                cmd.Parameters.AddWithValue("@Tuesday", specifiedWorkout.MyTuesday);
                cmd.Parameters.AddWithValue("@Wednesday", specifiedWorkout.MyWednesday);
                cmd.Parameters.AddWithValue("@Thursday", specifiedWorkout.MyThursday);
                cmd.Parameters.AddWithValue("@Friday", specifiedWorkout.MyFriday);
                cmd.Parameters.AddWithValue("@Saturday", specifiedWorkout.MySaturday);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;

            }
            catch
            {
                return false;
            }
        }

        public List<SpecifiedWorkout> GetSpecifiedWorkouts(string UserName)
        {
            List<SpecifiedWorkout> workout = new List<SpecifiedWorkout>();
            
            string Command = "select * from SpecialWorkout join MyUser on SpecialWorkout.Trainerid = myUser.id where username = @username";
           
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            

            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@username", UserName);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int WorkoutId = reader.GetInt32(0);
                int MyTrainerId = reader.GetInt32(1);
                string Monday = reader.GetString(2);
                string Tuesday = reader.GetString(3);
                string Wednesday = reader.GetString(4);
                string Thursday = reader.GetString(5);
                string Friday = reader.GetString(6);
                string Saturday = reader.GetString(7);

                workout.Add(new SpecifiedWorkout(WorkoutId, MyTrainerId, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday));
            }
            reader.Close();
            con.Close();
            return workout;

        }

        public bool DeleteWorkout(int WorkoutId)
        {
            try
            {
                string Command = "delete from specialWorkout where workoutId=@workoutId";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@workoutId", WorkoutId);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateTrainer(string MyUserName, string UserName, string Password, string FirstName, string LastName, string PhoneNumber, string Email)
        {
            try
            {
                string Command = "update myuser set UserName=@UserName, Password=@Password, FirstName=@FirstName, LastName=@LastName, PhoneNumber=@PhoneNumber, Email=@Email where id=@id";
                string IdCommand = "select id from myuser where username=@username";
                int Id;
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand id = new SqlCommand(IdCommand, con);
                id.Parameters.AddWithValue("@userName", MyUserName);
                Id = Convert.ToInt32(id.ExecuteScalar());
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@UserName", UserName);
                cmd.Parameters.AddWithValue("@Password", Password);
                cmd.Parameters.AddWithValue("@FirstName", FirstName);
                cmd.Parameters.AddWithValue("@LastName", LastName);
                cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
                cmd.Parameters.AddWithValue("@Email", Email);
                cmd.Parameters.AddWithValue("@Id", Id);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }



        public List<Performance> GetPerformance(int Id)
        {
            List<Performance> myPerformance = new List<Performance>();

            string Command = "select * from performance where memberid=@memberid";

            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();


            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@memberid", Id);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int PerformanceId = reader.GetInt32(0);
                int MemberId = reader.GetInt32(1);
                DateTime Date = reader.GetDateTime(2);
                int Duration = reader.GetInt32(3);
                int Calories = reader.GetInt32(4);
                int Distance = reader.GetInt32(5);
                int HeartBeat = reader.GetInt32(6);

                myPerformance.Add(new Performance(PerformanceId, MemberId, Date, Duration, Calories, Distance, HeartBeat));
            }
            reader.Close();
            con.Close();
            return myPerformance;

        }


    }



}

