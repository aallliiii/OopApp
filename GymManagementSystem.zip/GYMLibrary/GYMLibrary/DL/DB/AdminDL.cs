﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYMLibrary.DL
{
    public class AdminDL : MyUserDL, IManageMembers, ITrainer, IManageEmployees
    {
        public List<MyUser> ViewMember(string UserName)
        {
            List<MyUser> users = new List<MyUser>();
            string Command = "select UserName, Password, FirstName, LastName, PhoneNumber, Email, Role from myUser where username=@username";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@UserName", UserName);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string userName = reader.GetString(0);
                string Password = reader.GetString(1);
                string FirstName = reader.GetString(2);
                string LastName = reader.GetString(3);
                string PhoneNumber = reader.GetString(4);
                string Email = reader.GetString(5);
                int Role = reader.GetInt32(6);

                users.Add(new MyAdmin(userName, Password, FirstName, LastName, PhoneNumber, Email, Role));
            }

            reader.Close();
            con.Close();
            return users;
        }

        public List<MyMember> ViewMember()
        {
            List<MyMember> users = new List<MyMember>();
            string Command = "select UserName, Password, FirstName, LastName, PhoneNumber, Email, Role from myUser where role = 3";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string UserName = reader.GetString(0);
                string Password = reader.GetString(1);
                string FirstName = reader.GetString(2);
                string LastName = reader.GetString(3);
                string PhoneNumber = reader.GetString(4);
                string Email = reader.GetString(5);
                int Role = reader.GetInt32(6);

                users.Add(new MyMember(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role));
            }

            reader.Close();
            con.Close();
            return users;
        }

        public bool UpdateMember(string OldUserName, MyMember myMember)
        {
            try
            {
                string Command = "update MyUser set UserName=@UserName, Password=@Password, FirstName=@FirstName, LastName=@LastName, phoneNumber=@phoneNumber, Email=@Email where id=@id";
                string IdCommand = "select id from MyUser where username=@Username";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand FindId = new SqlCommand(IdCommand, con);
                FindId.Parameters.AddWithValue("@UserName", OldUserName);
                int id = Convert.ToInt32(FindId.ExecuteScalar());

                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@UserName", myMember.MyUserName);
                cmd.Parameters.AddWithValue("@Password", myMember.MyPassword);
                cmd.Parameters.AddWithValue("@FirstName", myMember.MyFirstName);
                cmd.Parameters.AddWithValue("@LastName", myMember.MyLastName);
                cmd.Parameters.AddWithValue("PhoneNumber", myMember.MyPhoneNumber);
                cmd.Parameters.AddWithValue("@Email", myMember.MyEmail);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }



        public bool DeleteMember(string UserName)
        {
            string Command = "delete from myUser where UserName = @UserName";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@UserName", UserName);
            int rows = cmd.ExecuteNonQuery();
            con.Close();

            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }



        public bool AddEmployees(Employees employee, string Username)
        {
            try
            {
                string CommandId = "select id from myuser where username=@username";
                string Command = "insert into Employee values (@FirstName, @LastName, @Designation, @Salary, @AdminId)";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand id = new SqlCommand(CommandId, con);
                id.Parameters.AddWithValue("@username", Username);
                int UserId = Convert.ToInt32(id.ExecuteScalar());
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@FirstName", employee.MyFirstName);
                cmd.Parameters.AddWithValue("@LastName", employee.MyLastName);
                cmd.Parameters.AddWithValue("@Designation", employee.MyDesignation);
                cmd.Parameters.AddWithValue("@Salary", employee.MySalary);
                cmd.Parameters.AddWithValue("@AdminId", UserId);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Employees> ViewEmployee(string id)
        {
            List<Employees> employees = new List<Employees>();
            string Command = "select * from employee where employee_id=@employee_id";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@employee_id", int.Parse(id));
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int Id = reader.GetInt32(0);
                string FirstName = reader.GetString(1);
                string LastName = reader.GetString(2);
                string Designation = reader.GetString(3);
                string Salary = reader.GetString(4);


                employees.Add(new Employees(Id, FirstName, LastName, Designation, Salary));
            }

            reader.Close();
            con.Close();
            return employees;
        }

        public List<Employees> ViewEmployee()
        {
            List<Employees> employees = new List<Employees>();
            string Command = "select * from employee";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int Id = reader.GetInt32(0);
                string FirstName = reader.GetString(1);
                string LastName = reader.GetString(2);
                string Designation = reader.GetString(3);
                string Salary = reader.GetString(4);

                employees.Add(new Employees(Id, FirstName, LastName, Designation, Salary));

            }

            reader.Close();
            con.Close();
            return employees;
        }

        public bool UpdateEmployees(Employees employee)
        {
            try
            {


                string Command = "update employee set FirstName=@FirstName, LastName=@LastName, Designation=@Designation, Salary=@Salary where employee_id=@employee_id";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@FirstName", employee.MyFirstName);
                cmd.Parameters.AddWithValue("@LastName", employee.MyLastName);
                cmd.Parameters.AddWithValue("@Designation", employee.MyDesignation);
                cmd.Parameters.AddWithValue("@Salary", employee.MySalary);
                cmd.Parameters.AddWithValue("@employee_id", employee.MyEmployeeId);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }

        }

        public bool DeleteEmployees(int id)
        {
            try
            {

                string Command = "delete from employee where employee_id=@employee_id";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@employee_id", id);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Salary> ViewSalary()
        {
            List<Salary> salaryList = new List<Salary>();
            string Command = "select salary_id, employee_id, PaymentDate, PaymentMethod from salary";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int SalaryId = reader.GetInt32(0);
                int EmployeeId = reader.GetInt32(1);
                string Date = (reader.GetDateTime(2)).ToString();
                string PaymentMethod = reader.GetString(3);

                salaryList.Add(new Salary(SalaryId, EmployeeId, Date, PaymentMethod));

            }

            reader.Close();
            con.Close();
            return salaryList;
        }

        public bool AddSalary(int Id, string Method)
        {
            string Command = "insert into salary values (@employee_id,@paymentDate,@paymentMethod)";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@employee_id", Id);
            cmd.Parameters.AddWithValue("@paymentDate", DateTime.Now.Date);
            cmd.Parameters.AddWithValue("@paymentMethod", Method);
            cmd.ExecuteNonQuery();
            return true;
        }

        public bool DeleteTrainer(string UserName)
        {
            try
            {

                string Command = "delete from myUser where userName=@userName";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();


                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@userName", UserName);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }

        }

        public List<MyUser> GetMyUsers()
        {
            List<MyUser> users = new List<MyUser>();
            string Command = "select UserName, Password, FirstName, LastName, PhoneNumber, Email, Role from myUser";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string UserName = reader.GetString(0);
                string Password = reader.GetString(1);
                string FirstName = reader.GetString(2);
                string LastName = reader.GetString(3);
                string PhoneNumber = reader.GetString(4);
                string Email = reader.GetString(5);
                int Role = reader.GetInt32(6);

                users.Add(new MyAdmin(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role));
            }

            reader.Close();
            con.Close();
            return users;
        }

        public List<MyUser> GetMyUsers(string UserName)
        {
            List<MyUser> users = new List<MyUser>();
            string Command = "select UserName, Password, FirstName, LastName, PhoneNumber, Email, Role from myUser where username=@username";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@UserName", UserName);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string userName = reader.GetString(0);
                string Password = reader.GetString(1);
                string FirstName = reader.GetString(2);
                string LastName = reader.GetString(3);
                string PhoneNumber = reader.GetString(4);
                string Email = reader.GetString(5);
                int Role = reader.GetInt32(6);

                users.Add(new MyAdmin(userName, Password, FirstName, LastName, PhoneNumber, Email, Role));
            }

            reader.Close();
            con.Close();
            return users;
        }



        public List<Payments> GetMyPayments()
        {
            List<Payments> payments = new List<Payments>();
            string Command = "select * from fees";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int FeesId = reader.GetInt32(0);
                int MemberId = reader.GetInt32(1);
                int Months = reader.GetInt32(2);
                int Amount = reader.GetInt32(3);
                string PaymentMethod = reader.GetString(4);
                DateTime Date = reader.GetDateTime(5);

                payments.Add(new Payments(FeesId, MemberId, Months, Amount, PaymentMethod, Date));
            }

            reader.Close();
            con.Close();
            return payments;
        }

        public List<Payments> GetMyPayments(int Id)
        {
            List<Payments> payments = new List<Payments>();
            string Command = "select * from fees where memberid=@memberid";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@memberid", Id);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int FeesId = reader.GetInt32(0);
                int MemberId = reader.GetInt32(1);
                int Months = reader.GetInt32(2);
                int Amount = reader.GetInt32(3);
                string PaymentMethod = reader.GetString(4);
                DateTime Date = reader.GetDateTime(5);

                payments.Add(new Payments(FeesId, MemberId, Months, Amount, PaymentMethod, Date));
            }

            reader.Close();
            con.Close();
            return payments;
        }

        public bool CheckMemberUsername(string Username)
        {

            string Command = "select id from myuser where username=@username and role = 3";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@username", Username);
            int id = Convert.ToInt32(cmd.ExecuteScalar());

            if (id > 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        public bool CheckEmployeeId(int id)
        {


            string Command = "select employee_id from employee where employee_id=@employee_id";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@employee_id", id);
            int e_id = Convert.ToInt32(cmd.ExecuteScalar());

            if (e_id > 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        public bool TrainerCheck(string Username)
        {
            int id = 0;
            string Command = "select id from myuser where username=@username and role = 2";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@username", Username);
            id = Convert.ToInt32(cmd.ExecuteScalar());
            if (id > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public List<string> GetUsernameList()
        {
            List<string> usernames = new List<string>();

            string query = "SELECT username FROM myUser WHERE role = 3";

            using (SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            usernames.Add(reader.GetString(0));
                        }
                    }
                }
            }



            return usernames;
        }



    }
}
