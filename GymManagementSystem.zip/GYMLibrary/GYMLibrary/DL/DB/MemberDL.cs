﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;

namespace GYMLibrary.DL
{
    public class MemberDL : MyUserDL
    {
        public List<SpecifiedWorkout> GetSpecifiedWorkouts()
        {
            List<SpecifiedWorkout> workout = new List<SpecifiedWorkout>();

            string Command = "select * from SpecialWorkout";

            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();

            SqlCommand cmd = new SqlCommand(Command, con);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int WorkoutId = reader.GetInt32(0);
                int MyTrainerId = reader.GetInt32(1);
                string Monday = reader.GetString(2);
                string Tuesday = reader.GetString(3);
                string Wednesday = reader.GetString(4);
                string Thursday = reader.GetString(5);
                string Friday = reader.GetString(6);
                string Saturday = reader.GetString(7);

                workout.Add(new SpecifiedWorkout(WorkoutId, MyTrainerId, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday));
            }
            reader.Close();
            con.Close();
            return workout;

        }

        public List<SpecifiedWorkout> GetSpecifiedWorkouts(int Id)
        {
            List<SpecifiedWorkout> workout = new List<SpecifiedWorkout>();

            string Command = "select * from SpecialWorkout where workoutid=@workoutid";

            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();

            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@workoutid", Id);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int WorkoutId = reader.GetInt32(0);
                int MyTrainerId = reader.GetInt32(1);
                string Monday = reader.GetString(2);
                string Tuesday = reader.GetString(3);
                string Wednesday = reader.GetString(4);
                string Thursday = reader.GetString(5);
                string Friday = reader.GetString(6);
                string Saturday = reader.GetString(7);

                workout.Add(new SpecifiedWorkout(WorkoutId, MyTrainerId, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday));
            }
            reader.Close();
            con.Close();
            return workout;

        }

        public bool SelectWorkout(int Id, string UserName)
        {
            try
            {
                string IdCommand = "select id from myUser where username=@username";
                string Command = "insert into selectedWorkout values (@SelectedWorkoutId,@DateSelected,@MemberId)";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand ID = new SqlCommand(IdCommand, con);
                ID.Parameters.AddWithValue("@username", UserName);
                int id = Convert.ToInt32(ID.ExecuteScalar());
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@SelectedWorkoutId", Id);
                cmd.Parameters.AddWithValue("@DateSelected", DateTime.Now.Date);
                cmd.Parameters.AddWithValue("@MemberId", id);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteWorkout(int WorkoutId)
        {
            try
            {
                string Command = "delete from selectedWorkout where selectedworkoutId=@selectedworkoutId";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@selectedworkoutId", WorkoutId);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public List<Session> GetSessions(int Id)
        {
            List<Session> MySessions = new List<Session>();

            string Command = "select * from sessions where sessionId=@sessionId";

            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();

            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@sessionid", Id);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int SessionId = reader.GetInt32(reader.GetOrdinal("SessionId"));
                int MyTrainerId = reader.GetInt32(reader.GetOrdinal("TrainerId"));
                DateTime MyDate = reader.GetDateTime(2);
                TimeSpan StartTime = reader.GetTimeSpan(3);
                TimeSpan EndTime = reader.GetTimeSpan(4);

                MySessions.Add(new Session(SessionId, MyTrainerId, MyDate, StartTime, EndTime));
            }
            reader.Close();
            con.Close();
            return MySessions;

        }

        public List<Session> GetSessions()
        {
            List<Session> MySessions = new List<Session>();

            string Command = "select * from sessions";

            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();

            SqlCommand cmd = new SqlCommand(Command, con);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int SessionId = reader.GetInt32(reader.GetOrdinal("SessionId"));
                int MyTrainerId = reader.GetInt32(reader.GetOrdinal("TrainerId"));
                DateTime MyDate = reader.GetDateTime(2);
                TimeSpan StartTime = reader.GetTimeSpan(3);
                TimeSpan EndTime = reader.GetTimeSpan(4);

                MySessions.Add(new Session(SessionId, MyTrainerId, MyDate, StartTime, EndTime));
            }
            reader.Close();
            con.Close();
            return MySessions;

        }

        public bool SelectSessions(int Id, string UserName)
        {
            try
            {
                string IdCommand = "select id from myUser where username=@username";
                string Command = "insert into selectedSession values (@SelectedSessionId,@DateSelected,@MemberId)";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand ID = new SqlCommand(IdCommand, con);
                ID.Parameters.AddWithValue("@username", UserName);
                int id = Convert.ToInt32(ID.ExecuteScalar());
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@SelectedSessionId", Id);
                cmd.Parameters.AddWithValue("@DateSelected", DateTime.Now.Date);
                cmd.Parameters.AddWithValue("@MemberId", id);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteSessions(int SessionId)
        {
            try
            {
                string Command = "delete from selectedSession where Selectedsessionid=@Selectedsessionid";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@SelectedsessionId", SessionId);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool AddPerformance(string UserName,Performance performance)
        {
            try
            {
                string IdCommand = "select id from myUser where username=@username";
                string Command = "insert into performance values (@memberId, @date, @WorkoutDurationMinutes, @CaloriesBurned, @DistanceCoveredKm, @HeartBeatAvg)";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();

                SqlCommand ID = new SqlCommand(IdCommand, con);
                ID.Parameters.AddWithValue("@UserName", UserName);
                int id = Convert.ToInt32(ID.ExecuteScalar());

                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@memberid", id);
                cmd.Parameters.AddWithValue("@date", DateTime.Now.Date);
                cmd.Parameters.AddWithValue("@WorkoutDurationMinutes", performance.MyDuration);
                cmd.Parameters.AddWithValue("@CaloriesBurned", performance.MyCalories);
                cmd.Parameters.AddWithValue("@DistanceCoveredKm", performance.MyDistance);
                cmd.Parameters.AddWithValue("@heartBeatAvg", performance.MyHeartBeat);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;


            }
            catch
            {
                return false;
            }
        }

        public List<Performance> GetPerformance(int Id)
        {
            List<Performance> myPerformance = new List<Performance>();

            string Command = "select * from performance where performanceid=@performanceid";

            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();


            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@performanceid", Id);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int PerformanceId = reader.GetInt32(0);
                int MemberId = reader.GetInt32(1);
                DateTime Date = reader.GetDateTime(2);
                int Duration = reader.GetInt32(3);
                int Calories = reader.GetInt32(4);
                int Distance = reader.GetInt32(5);
                int HeartBeat = reader.GetInt32(6);

                myPerformance.Add(new Performance(PerformanceId, MemberId, Date, Duration, Calories, Distance, HeartBeat));
            }
            reader.Close();
            con.Close();
            return myPerformance;

        }

        public bool DeletePerformance(int Id)
        {
            try
            {
                string Command = "delete from performance where performanceid=@performanceid";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@performanceid", Id);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool TransferFees (int Months, int Fees, string PaymentMethod, string UserName)
        {
            try
            {
                string IdCommand = "select id from myUser where username=@username";
                string Command = "insert into fees values (@memberId, @numberOfMonths, @Amount, @paymentMethod, @datePayed)";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand command = new SqlCommand(IdCommand, con);
                command.Parameters.AddWithValue("@username", UserName);
                int id = Convert.ToInt32(command.ExecuteScalar());
                SqlCommand cmd = new SqlCommand(Command, con);
                cmd.Parameters.AddWithValue("@memberId", id);
                cmd.Parameters.AddWithValue("@numberOfMonths", Months);
                cmd.Parameters.AddWithValue("@Amount", Fees);
                cmd.Parameters.AddWithValue("@paymentMethod", PaymentMethod);
                cmd.Parameters.AddWithValue("@datePayed", DateTime.Now.Date);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
