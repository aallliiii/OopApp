﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;

namespace GYM_Management_System.Admin
{
    public partial class AdminMenu : Form
    {
        
        public AdminMenu()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void AdminMenu_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            this.Hide();
            settings.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            ManageMembers manageMembers = new ManageMembers();
            this.Hide();
            manageMembers.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            ManageEmployees manageEmployees = new ManageEmployees();
            this.Hide();
            manageEmployees.ShowDialog();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            DeleteTrainer deleteTrainer = new DeleteTrainer();
            this.Hide();
            deleteTrainer.ShowDialog();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            ViewAllUsers viewAllUsers = new ViewAllUsers();
            this.Hide();
            viewAllUsers.ShowDialog();
        }
    }
}
