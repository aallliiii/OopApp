﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Admin
{
    public partial class DeleteEmployee : Form
    {
        public DeleteEmployee()
        {
            InitializeComponent();
            AddItems();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageEmployees manageEmployees = new ManageEmployees();
            this.Hide();
            manageEmployees.ShowDialog();
        }

        private void DeleteEmployee_Load(object sender, EventArgs e)
        {

        }

        private void AddItems()
        {

            string query = "SELECT employee_id FROM employee";



            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);




            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();

            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id;
            id = int.Parse(comboBox1.Text);
            if (ObjectHandler.GetAdminDL().DeleteEmployees(id))
            {
                MessageBox.Show("Employee Deleted Successfully!");
            }
            else
            {
                MessageBox.Show("Error Deleting Employee!");
            }
        }
    }
}
