﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Admin
{
    public partial class DeleteTrainer : Form
    {
        public DeleteTrainer()
        {
            InitializeComponent();
            AddItems();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.ShowDialog();
        }

        private void DeleteTrainer_Load(object sender, EventArgs e)
        {

        }
        private void AddItems()
        {

            string query = "SELECT username FROM myUser where role = 2";



            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);




            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetString(0));
            }


            reader.Close();

            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string UserName;
            UserName = comboBox1.Text;

            if (comboBox1.Text != string.Empty)
            {

                if (ObjectHandler.GetAdminDL().DeleteTrainer(UserName))
                {
                    MessageBox.Show("Trainer Deleted Successfully!");
                }

                else
                {
                    MessageBox.Show("Error Deleting Trainer");
                }
            }
            else
            {
                MessageBox.Show("Select Trainer UserName to Delete");
            }
        }
    }
}
