﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Admin
{
    public partial class ViewPayment : Form
    {

        private DataTable dataTable = new DataTable();
        public ViewPayment()
        {
            InitializeComponent();
            AddItems();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ManageMembers manageMembers = new ManageMembers();
            this.Hide();
            manageMembers.ShowDialog();

        }

        private void AddItems()
        {

            string query = "SELECT distinct MemberId FROM fees";



            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);




            SqlDataReader reader = command.ExecuteReader();


            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            string UserName = comboBox1.Text;
            AddColumnIfNotExists("FeesId", typeof(int));
            AddColumnIfNotExists("MemberId", typeof(int));
            AddColumnIfNotExists("NumberOfMonths", typeof(int));
            AddColumnIfNotExists("Amount", typeof(int));
            AddColumnIfNotExists("PaymentMethod", typeof(string));
            AddColumnIfNotExists("DatePayed", typeof(DateTime));
            

            List<Payments> payments = new List<Payments>();

            payments = ObjectHandler.GetAdminDL().GetMyPayments();

            foreach (Payments pay in payments)
            {
                dataTable.Rows.Add(pay.MyFeesId,pay.MyMemberId,pay.MyMonths,pay.MyAmount,pay.MyPaymentMethod,pay.MyDate);

            }

            dataGridView1.DataSource = dataTable;
        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != string.Empty)
            {
                DataTable dataSource = (DataTable)dataGridView1.DataSource;
                if (dataSource != null)
                {
                    dataSource.Rows.Clear();
                }
                string UserName = comboBox1.Text;
                AddColumnIfNotExists("FeesId", typeof(int));
                AddColumnIfNotExists("MemberId", typeof(int));
                AddColumnIfNotExists("NumberOfMonths", typeof(int));
                AddColumnIfNotExists("Amount", typeof(int));
                AddColumnIfNotExists("PaymentMethod", typeof(string));
                AddColumnIfNotExists("DatePayed", typeof(DateTime));

                int id = int.Parse(comboBox1.Text);

                List<Payments> payments = new List<Payments>();

                payments = ObjectHandler.GetAdminDL().GetMyPayments(id);

                foreach (Payments pay in payments)
                {
                    dataTable.Rows.Add(pay.MyFeesId, pay.MyMemberId, pay.MyMonths, pay.MyAmount, pay.MyPaymentMethod, pay.MyDate);

                }

                dataGridView1.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show("Select Member Id");
            }
        }
    }
}
