﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Admin
{
    public partial class Add_Employees : Form
    {
        public Add_Employees()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string FirstName;
            string LastName;
            string Designation;
            string Salary;
            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty && textBox3.Text != string.Empty && textBox4.Text != string.Empty)
            {
                FirstName = textBox1.Text;
                LastName = textBox2.Text;
                Designation = textBox3.Text;
                Salary = textBox4.Text;
                Employees employee = new Employees(FirstName, LastName, Designation, Salary);
                if (ObjectHandler.GetAdminDL().AddEmployees(employee,SignIn.UserName))
                {
                    MessageBox.Show("Employee Added Successfully!");
                }
                else
                {
                    MessageBox.Show("Error Adding Employee!");
                }
            }
            else
            {
                MessageBox.Show("Please fill the required fields");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageEmployees manageEmployees = new ManageEmployees();
            this.Hide();
            manageEmployees.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
