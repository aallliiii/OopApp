﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_Management_System.Admin
{
    public partial class ManageEmployees : Form
    {
        public ManageEmployees()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Add_Employees add_Employees = new Add_Employees();
            this.Hide();
            add_Employees.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewEmployees viewEmployees = new ViewEmployees();
            this.Hide();
            viewEmployees.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UpdateEmployees updateEmployees = new UpdateEmployees();
            this.Hide();
            updateEmployees.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DeleteEmployee deleteEmployee = new DeleteEmployee();
            this.Hide();
            deleteEmployee.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MySalary salary = new MySalary();   
            this.Hide();
            salary.ShowDialog();
        }
    }
}
