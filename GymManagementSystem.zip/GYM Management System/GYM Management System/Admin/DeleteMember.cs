﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.DL;
using GYMLibrary.Utilities;


namespace GYM_Management_System.Admin
{
    public partial class DeleteMember : Form
    {
        public DeleteMember()
        {
            InitializeComponent();
            
            AddUsernames();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DeleteMember_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageMembers manageMembers = new ManageMembers();
            this.Hide();
            manageMembers.ShowDialog();
        }
        
        private void AddUsernames ()
        {
            comboBox1.Items.Clear ();
            List<string> names = new List<string>();
            names = ObjectHandler.ManageMembers().GetUsernameList();

            foreach (string name in names)
            {
                comboBox1.Items.Add (name); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string UserName;
            UserName = comboBox1.Text;
            AdminDL admin = new AdminDL();

            
                if (ObjectHandler.ManageMembers().DeleteMember(UserName))
                {
                    MessageBox.Show("Member Deleted Successfully!");
                }

                else
                {
                    MessageBox.Show("Error Deleting Member");
                }
            
        }
    }
}
