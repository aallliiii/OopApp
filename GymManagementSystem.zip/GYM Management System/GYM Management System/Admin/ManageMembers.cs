﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYM_Management_System.Trainer;

namespace GYM_Management_System.Admin
{
    public partial class ManageMembers : Form
    {
        public ManageMembers()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (SignIn.ID == 1)
            {
                AdminMenu menu = new AdminMenu();
                this.Hide();
                menu.ShowDialog();
            }
            else if (SignIn.ID == 2)
            {
                TrainerMenu trainerMenu = new TrainerMenu();
                this.Hide();
                trainerMenu.ShowDialog();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewMembers viewMembers = new ViewMembers();
            this.Hide();
            viewMembers.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddMembers addMembers = new AddMembers();
            this.Hide();
            addMembers.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UpdateMembers updateMembers = new UpdateMembers();
            this.Hide();
            updateMembers.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ViewPayment viewPayment = new ViewPayment();
            this.Hide();
            viewPayment.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DeleteMember deleteMember = new DeleteMember();
            this.Hide();
            deleteMember.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
