﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Admin
{
    public partial class MySalary : Form
    {

        private DataTable dataTable = new DataTable();
        public MySalary()
        {
            InitializeComponent();
            AddItems();
            LoadSalaryData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageEmployees manageEmployees = new ManageEmployees();
            this.Hide();
            manageEmployees.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AddItems()
        {

            string query = "SELECT employee_id FROM employee";



            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);




            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();

            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Id;
            string PaymentMethod;
            Id = int.Parse(comboBox1.Text);
            PaymentMethod = comboBox2.Text;
            if (ObjectHandler.GetAdminDL().AddSalary(Id, PaymentMethod))
            {
                MessageBox.Show("Salary Added Successfully");
                LoadSalaryData();

            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void LoadSalaryData()
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("SalaryId", typeof(int));
            AddColumnIfNotExists("EmployeeId", typeof(int));
            AddColumnIfNotExists("Date", typeof(string));
            AddColumnIfNotExists("PaymentMethod", typeof(string));


            List<Salary> salary = new List<Salary>();

            salary = ObjectHandler.GetAdminDL().ViewSalary();

           

            foreach (Salary sal in salary)
            {
                dataTable.Rows.Add(sal.MySalaryId,sal.MyEmployeeId,sal.MyDate,sal.MyPaymentMethod);

            }

            dataGridView1.DataSource = dataTable;
        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

    }

}
