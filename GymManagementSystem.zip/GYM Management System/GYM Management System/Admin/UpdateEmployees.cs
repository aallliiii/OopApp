﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GYM_Management_System.Admin
{
    public partial class UpdateEmployees : Form
    {

        private DataTable dataTable = new DataTable();
        public UpdateEmployees()
        {
            InitializeComponent();
            LoadDataEmployee();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox5.Text = row.Cells[0].Value.ToString();
                textBox1.Text = row.Cells[1].Value.ToString();
                textBox2.Text = row.Cells[2].Value.ToString();
                textBox3.Text = row.Cells[3].Value.ToString();
                textBox4.Text = row.Cells[4].Value.ToString();
            }
        }

        private void LoadDataEmployee()
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("EmployeeID", typeof(int));
            AddColumnIfNotExists("FirstName", typeof(string));
            AddColumnIfNotExists("LastName", typeof(string));
            AddColumnIfNotExists("Designation", typeof(string));
            AddColumnIfNotExists("Salary", typeof(double));

            List<Employees> employees = new List<Employees>();

            employees = ObjectHandler.GetAdminDL().ViewEmployee();

            foreach (Employees employee in employees)
            {
                dataTable.Rows.Add(employee.MyEmployeeId, employee.MyFirstName, employee.MyLastName, employee.MyDesignation, employee.MySalary);

            }

            dataGridView1.DataSource = dataTable;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageEmployees manageEmployees = new ManageEmployees();
            this.Hide();
            manageEmployees.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Id;
            string FirstName;
            string LastName;
            string Designation;
            string Salary;
            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty && textBox3.Text != string.Empty && textBox4.Text != string.Empty && textBox5.Text != string.Empty)
            {
                Id = int.Parse(textBox5.Text);
                FirstName = textBox1.Text;
                LastName = textBox2.Text;
                Designation = textBox3.Text;
                Salary = textBox4.Text;
                Employees employees = new Employees(Id, FirstName, LastName, Designation, Salary);
                if (ObjectHandler.GetAdminDL().UpdateEmployees(employees))
                {
                    MessageBox.Show("Employee Update Successfully!");

                }
                else
                {
                    MessageBox.Show("Error Updating Employee");
                }
            }
            else
            {
                MessageBox.Show("Fill the required Fields!");
            }
        }

        private void UpdateEmployees_Load(object sender, EventArgs e)
        {

        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
