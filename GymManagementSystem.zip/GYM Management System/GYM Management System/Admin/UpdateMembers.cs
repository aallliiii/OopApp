﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Admin
{
    public partial class UpdateMembers : Form
    {
        string MyEmail = "^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$";
        int LengthMax = 11;
        private DataTable dataTable = new DataTable();

        public UpdateMembers()
        {
            InitializeComponent();
        }

        private void UpdateMembers_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("UserName", typeof(string));
            AddColumnIfNotExists("Password", typeof(string));
            AddColumnIfNotExists("FirstName", typeof(string));
            AddColumnIfNotExists("LastName", typeof(string));
            AddColumnIfNotExists("PhoneNumber", typeof(string));
            AddColumnIfNotExists("Email", typeof(string));
            AddColumnIfNotExists("Role", typeof(int));

            List<MyMember> myMembers = new List<MyMember>();

            myMembers = ObjectHandler.ManageMembers().ViewMember();

            foreach (MyMember user in myMembers)
            {
                dataTable.Rows.Add(user.MyUserName, user.MyPassword, user.MyFirstName, user.MyLastName, user.MyPhoneNumber, user.MyEmail, user.MyRole);

            }

            dataGridView1.DataSource = dataTable;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageMembers manageMembers = new ManageMembers();
            this.Hide();
            manageMembers.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox7.Text = row.Cells[0].Value.ToString();
                textBox2.Text = row.Cells[1].Value.ToString();
                textBox3.Text = row.Cells[2].Value.ToString();
                textBox4.Text = row.Cells[3].Value.ToString();
                textBox5.Text = row.Cells[4].Value.ToString();
                textBox6.Text = row.Cells[5].Value.ToString();
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string OldUserName;
            string NewUserName;
            string Password;
            string FirstName;
            string LastName;
            string PhoneNumber;
            string Email;

            NewUserName = textBox1.Text;
            Password = textBox2.Text;
            FirstName = textBox3.Text;
            LastName = textBox4.Text;
            PhoneNumber = textBox5.Text;
            Email = textBox6.Text;
            OldUserName = textBox7.Text;

            AdminDL admin = ObjectHandler.GetAdminDL();
            if (!Regex.IsMatch(textBox6.Text, MyEmail))
            {
                errorProvider1.SetError(this.textBox6, "Email Format is Incorrect");
            }
            else if (textBox5.Text.Length > LengthMax || textBox5.Text.Length < LengthMax)
            {
                errorProvider2.SetError(this.textBox5, "Contact Number is not Correct");
            }
            
            else
            {

                MyMember myMember = new MyMember(NewUserName, Password, FirstName, LastName, PhoneNumber, Email);

                if (ObjectHandler.ManageMembers().UpdateMember(OldUserName, myMember))
                {
                    MessageBox.Show("Member Updated Successfully!");


                }
                else
                {
                    MessageBox.Show("Error updating database Member!");
                }

            }
        }
        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text.Length > LengthMax || textBox5.Text.Length < LengthMax)
            {
                errorProvider2.SetError(this.textBox5, "Contact Number is not Correct");
            }
            else
            {
                errorProvider2.Clear();
            }
        }

        private void textBox6_Leave(object sender, EventArgs e)
        {
            if (!Regex.IsMatch(textBox6.Text, MyEmail))
            {
                errorProvider1.SetError(this.textBox6, "Email Format is Incorrect");
            }
            else
            {
                errorProvider1.Clear();
            }
        }
    }
}
