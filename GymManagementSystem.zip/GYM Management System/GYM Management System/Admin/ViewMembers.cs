﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Admin
{
    public partial class ViewMembers : Form
    {
        private DataTable dataTable = new DataTable();
        public ViewMembers()
        {
            InitializeComponent();
            AddItems();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ManageMembers manageMembers = new ManageMembers();  
            this.Hide();
            manageMembers.ShowDialog();
        }

        private void ViewMembers_Load(object sender, EventArgs e)
        {

        }

        private void AddItems()
        {

            string query = "SELECT UserName FROM myUser where role = 3 ";



            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);




            SqlDataReader reader = command.ExecuteReader();


            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetString(0));
            }


            reader.Close();
            connection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            string UserName = comboBox1.Text;
            AddColumnIfNotExists("UserName", typeof(string));
            AddColumnIfNotExists("Password", typeof(string));
            AddColumnIfNotExists("FirstName", typeof(string));
            AddColumnIfNotExists("LastName", typeof(string));
            AddColumnIfNotExists("PhoneNumber", typeof(string));
            AddColumnIfNotExists("Email", typeof(string));
            AddColumnIfNotExists("Role", typeof(int));

            List<MyUser> myUsers = new List<MyUser>();

            myUsers = ObjectHandler.GetAdminDL().ViewMember(UserName);

            foreach (MyUser user in myUsers)
            {
                dataTable.Rows.Add(user.MyUserName, user.MyPassword, user.MyFirstName, user.MyLastName, user.MyPhoneNumber, user.MyEmail, user.MyRole);

            }

            dataGridView1.DataSource = dataTable;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("UserName", typeof(string));
            AddColumnIfNotExists("Password", typeof(string));
            AddColumnIfNotExists("FirstName", typeof(string));
            AddColumnIfNotExists("LastName", typeof(string));
            AddColumnIfNotExists("PhoneNumber", typeof(string));
            AddColumnIfNotExists("Email", typeof(string));
            AddColumnIfNotExists("Role", typeof(int));

            List<MyMember> myMembers = new List<MyMember>();

            myMembers = ObjectHandler.ManageMembers().ViewMember();

            foreach (MyMember user in myMembers)
            {
                dataTable.Rows.Add(user.MyUserName, user.MyPassword, user.MyFirstName, user.MyLastName, user.MyPhoneNumber, user.MyEmail, user.MyRole);

            }

            dataGridView1.DataSource = dataTable;
        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }
    }
}
