﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Trainer
{
    public partial class DeleteSession : Form
    {
        public DeleteSession()
        {
            InitializeComponent();
            AddItems();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageSessions manageSessions = new ManageSessions();
            this.Hide();
            manageSessions.ShowDialog();
        }

        private void AddItems()
        {
            string MyUserName;
            string query = "SELECT sessionId FROM sessions join myUser on Sessions.TrainerId=MyUser.ID where UserName=@UserName";

            MyUserName = SignIn.UserName;

            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@UserName", MyUserName);



            SqlDataReader reader = command.ExecuteReader();


            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Id;
            if (comboBox1.Text != string.Empty)
            {
                Id = int.Parse(comboBox1.Text);
                if (ObjectHandler.GetTrainerDL().DeleteSessions(Id))
                {
                    MessageBox.Show("Session Deleted Successfully!");
                }

                else
                {
                    MessageBox.Show("Error Deleting Session");
                }
            }
            else
            {
                MessageBox.Show("Please select a session!");
            }
            AddItems();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
