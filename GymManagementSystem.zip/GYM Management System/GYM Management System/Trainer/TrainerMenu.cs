﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Admin;
using GYM_Management_System.Login;

namespace GYM_Management_System.Trainer
{
    public partial class TrainerMenu : Form
    {
        public TrainerMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            this.Hide();
            signIn.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            ManageMembers manageMembers = new ManageMembers();
            this.Hide();
            manageMembers.ShowDialog();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            this.Hide();
            signIn.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ManageSessions manageSessions = new ManageSessions();
            this.Hide();
            manageSessions.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ManageSpecifiedWorkout manageSpecifiedWorkout = new ManageSpecifiedWorkout();
            this.Hide();
            manageSpecifiedWorkout.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TrainerSettings trainerSettings = new TrainerSettings();
            this.Hide();
            trainerSettings.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ViewPerformanceT viewPerformanceT = new ViewPerformanceT();
            this.Hide(); 
            viewPerformanceT.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
