﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Trainer
{
    public partial class ViewWorkout : Form
    {
        private DataTable dataTable = new DataTable();  
        public ViewWorkout()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ManageSpecifiedWorkout manageSpecifiedWorkout = new ManageSpecifiedWorkout();
            this.Hide();
            manageSpecifiedWorkout.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("WorkoutId", typeof(int));
            AddColumnIfNotExists("TrainerId", typeof(int));
            AddColumnIfNotExists("Monday", typeof(string));
            AddColumnIfNotExists("Tuesday", typeof(string));
            AddColumnIfNotExists("Wednesday", typeof(string));
            AddColumnIfNotExists("Thursday", typeof(string));
            AddColumnIfNotExists("Friday", typeof(string));
            AddColumnIfNotExists("Saturday", typeof(string));

            List<SpecifiedWorkout> myWorkout = new List<SpecifiedWorkout>();

            string UserName = SignIn.UserName;

            myWorkout = ObjectHandler.GetTrainerDL().GetSpecifiedWorkouts(UserName);


            foreach (SpecifiedWorkout workout in myWorkout)
            {
                dataTable.Rows.Add(workout.MyWorkoutId,workout.MyTrainer,workout.MyMonday,workout.MyTuesday,workout.MyWednesday,workout.MyThursday,workout.MyFriday,workout.MySaturday);

            }

            dataGridView1.DataSource = dataTable;
        }
        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
