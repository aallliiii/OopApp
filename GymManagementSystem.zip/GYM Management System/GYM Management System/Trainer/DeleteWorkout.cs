﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Trainer
{
    public partial class DeleteWorkout : Form
    {
        public DeleteWorkout()
        {
            InitializeComponent();
            AddItems();
        }

        private void DeleteWorkout_Load(object sender, EventArgs e)
        {

        }
        private void AddItems()
        {
            string MyUserName;
            string query = "SELECT workoutId FROM specialWorkout join myUser on SpecialWorkout.TrainerId=MyUser.ID where UserName=@UserName";

            MyUserName = SignIn.UserName;

            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@UserName", MyUserName);



            SqlDataReader reader = command.ExecuteReader();


            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();
            connection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageSpecifiedWorkout workout = new ManageSpecifiedWorkout();
            this.Hide();
            workout.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != string.Empty)
            {
                int workoutId = int.Parse(comboBox1.Text);
                if (ObjectHandler.GetTrainerDL().DeleteWorkout(workoutId))
                {
                    MessageBox.Show("Workout deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Error Deleting Workout");
                }
            }
            else
            {
                MessageBox.Show("Select any Workout Id to delete Workout!");
            }

            AddItems();
        }
    }
}
