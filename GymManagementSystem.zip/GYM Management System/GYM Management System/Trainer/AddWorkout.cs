﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Trainer
{
    public partial class AddWorkout : Form
    {
        public AddWorkout()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string UserName = SignIn.UserName;
            string Monday;
            string Tuesday;
            string Wednesday;
            string Thursday;
            string Friday;
            string Saturday;

            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty && textBox3.Text != string.Empty && textBox4.Text != string.Empty && textBox5.Text != string.Empty && textBox6.Text != string.Empty)
            {
                Monday = textBox1.Text;
                Tuesday = textBox2.Text;
                Wednesday = textBox3.Text;
                Thursday = textBox4.Text;
                Friday = textBox5.Text;
                Saturday = textBox6.Text;
                SpecifiedWorkout workout = new SpecifiedWorkout(Monday, Tuesday, Wednesday, Thursday, Friday, Saturday);
                if (ObjectHandler.GetTrainerDL().AddSpecifiedWorkout(UserName, workout))
                {
                    MessageBox.Show("Workout Added Successfully");
                }
                else
                {
                    MessageBox.Show("Error");
                }

            }
            else
            {
                MessageBox.Show("Please fill the required fields");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageSpecifiedWorkout manageSpecifiedWorkout = new ManageSpecifiedWorkout();
            this.Hide();
            manageSpecifiedWorkout.ShowDialog();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void AddWorkout_Load(object sender, EventArgs e)
        {

        }
    }
}
