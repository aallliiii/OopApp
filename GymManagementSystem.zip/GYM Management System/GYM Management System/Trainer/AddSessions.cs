﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Trainer
{
    public partial class AddSessions : Form
    {
        public AddSessions()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DateTime MyDate = dateTimePicker1.Value;
            TimeSpan StartTime = dateTimePicker2.Value.TimeOfDay;
            TimeSpan EndTime = dateTimePicker3.Value.TimeOfDay;
            Session session = new Session(MyDate, StartTime, EndTime);
            if (ObjectHandler.GetTrainerDL().AddSessions(session, SignIn.UserName) /*&& ObjectHandler.GetTrainerDL().AddSessionList(SignIn.UserName)*/)
            {
                MessageBox.Show("Session Added Successfully");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageSessions manageSessions = new ManageSessions();
            this.Hide();
            manageSessions.ShowDialog();
        }
    }
}
