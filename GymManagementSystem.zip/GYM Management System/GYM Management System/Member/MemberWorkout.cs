﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Trainer;

namespace GYM_Management_System.Member
{
    public partial class MemberWorkout : Form
    {
        public MemberWorkout()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MemberMenu memberMenu = new MemberMenu();
            this.Hide();
            memberMenu.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SelectWorkout selectWorkout = new SelectWorkout();
            this.Hide();
            selectWorkout.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewSelectedWorkout viewSelectedWorkout = new ViewSelectedWorkout();    
            this.Hide();
            viewSelectedWorkout.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DeleteSelectedWorkout deleteSelectedWorkout = new DeleteSelectedWorkout();  
            this.Hide();
            deleteSelectedWorkout.ShowDialog();
        }
    }
}
