﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class ViewSelectedSession : Form
    {
        private DataTable dataTable = new DataTable();  
        public ViewSelectedSession()
        {
            InitializeComponent();
            AddItems();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MemberSession memberSession = new MemberSession();
            this.Hide();
            memberSession.ShowDialog();
        }

        private void ViewSelectedSession_Load(object sender, EventArgs e)
        {

        }
        private void AddItems()
        {

            string query = "SELECT selectedsessionId FROM selectedSession join myUser on " +
                "selectedSession.MemberId=Myuser.Id where myUser.UserName=@UserName";


            string UserName = SignIn.UserName;
            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Username", UserName);



            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();

            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("SessionId", typeof(int));
            AddColumnIfNotExists("TrainerId", typeof(int));
            AddColumnIfNotExists("Date", typeof(DateTime));
            AddColumnIfNotExists("StartTime", typeof(TimeSpan));
            AddColumnIfNotExists("EndTime", typeof(TimeSpan));
            int id = int.Parse(comboBox1.Text);
            List<Session> sessions = new List<Session>();

            sessions = ObjectHandler.GetMemberDL().GetSessions(id);


            foreach (Session session in sessions)
            {
                dataTable.Rows.Add(session.MySessionId, session.MyTrainerId, session.Date, session.MyStartTime, session.MyEndTime);

            }

            dataGridView1.DataSource = dataTable;
        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }
    }
}
