﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class SelectWorkout : Form
    {

        private DataTable dataTable = new DataTable();
        public SelectWorkout()
        {
            InitializeComponent();
            LoadData();
        }

        private void SelectWorkout_Load(object sender, EventArgs e)
        {

        }

       private void LoadData ()
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("WorkoutId", typeof(int));
            AddColumnIfNotExists("TrainerId", typeof(int));
            AddColumnIfNotExists("Monday", typeof(string));
            AddColumnIfNotExists("Tuesday", typeof(string));
            AddColumnIfNotExists("Wednesday", typeof(string));
            AddColumnIfNotExists("Thursday", typeof(string));
            AddColumnIfNotExists("Friday", typeof(string));
            AddColumnIfNotExists("Saturday", typeof(string));

            List<SpecifiedWorkout> myWorkout = new List<SpecifiedWorkout>();

            string UserName = SignIn.UserName;

            myWorkout = ObjectHandler.GetMemberDL().GetSpecifiedWorkouts();


            foreach (SpecifiedWorkout workout in myWorkout)
            {
                dataTable.Rows.Add(workout.MyWorkoutId, workout.MyTrainer, workout.MyMonday, workout.MyTuesday, workout.MyWednesday, workout.MyThursday, workout.MyFriday, workout.MySaturday);

            }

            dataGridView1.DataSource = dataTable;

        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells[0].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemberWorkout memberWorkout = new MemberWorkout();
            this.Hide();
            memberWorkout.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Id;
            string UserName = SignIn.UserName;
            if (textBox1.Text!=string.Empty)
            {
                Id = int.Parse(textBox1.Text);
                
                if(ObjectHandler.GetMemberDL().SelectWorkout(Id,UserName))
                {
                    MessageBox.Show("Workout Selected Successfully");
                }
                else
                {
                    MessageBox.Show("Workout Already Selected");
                }
            }

            else
            {
                MessageBox.Show("Select a Workout");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
