﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class DeleteSelectedSession : Form
    {
        public DeleteSelectedSession()
        {
            InitializeComponent();
            AddItems();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemberSession memberSession = new MemberSession();
            this.Hide();
            memberSession.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text!=string.Empty)
            {
                int id = int.Parse(comboBox1.Text);
                
                if (ObjectHandler.GetMemberDL().DeleteSessions(id))
                {
                    MessageBox.Show("Session Deleted!");
                }
                else
                {
                    MessageBox.Show("Error Deleting Session");
                }

            }

            else
            {
                MessageBox.Show("Select a session to Delete!");
            }
            AddItems();
        }
        private void AddItems()
        {

            string query = "SELECT selectedsessionId FROM selectedSession join myUser on " +
                "selectedSession.MemberId=Myuser.Id where myUser.UserName=@UserName";


            string UserName = SignIn.UserName;
            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Username", UserName);



            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();

            connection.Close();
        }
    }
}
