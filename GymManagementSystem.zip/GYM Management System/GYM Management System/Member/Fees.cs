﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using GYM_Management_System.Login;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class Fees : Form
    {
        private int CalculatedFees = 0;
        private int Months;
        public Fees()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemberMenu memberMenu = new MemberMenu();
            this.Hide();
            memberMenu.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != string.Empty && comboBox2.Text != string.Empty)
            {
                string Package = comboBox1.Text;
                Months = int.Parse(comboBox2.Text);

                if (Package == "FitFusion Package")
                {
                    CalculatedFees = Months * 3000;
                }
                else if (Package == "StrengthForge Bundle")
                {
                    CalculatedFees = Months * 4000;
                }
                else
                {
                    CalculatedFees = Months * 5000;
                }

                MessageBox.Show(CalculatedFees.ToString());
            }
            else
            {
                MessageBox.Show("Fill the required fields");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (CalculatedFees != 0)
            {
                if (comboBox3.Text != string.Empty)
                {
                    string PaymentMethod = comboBox3.Text;
                    string UserName = SignIn.UserName;
                    if (ObjectHandler.GetMemberDL().TransferFees(Months, CalculatedFees, PaymentMethod, UserName))
                    {
                        MessageBox.Show("Fees Payed Successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Error Paying Fees!");
                    }
                }
                else
                {
                    MessageBox.Show("Select a payment Method");
                }
            }
            else
            {
                MessageBox.Show("Calculate Fees First!");
            }
        }

        private void Fees_Load(object sender, EventArgs e)
        {

        }
    }
}
