﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class ViewPerformance : Form
    {
        private DataTable dataTable = new DataTable();  
        public ViewPerformance()
        {
            InitializeComponent();
            AddItems();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MemberPerformance memberPerformance = new MemberPerformance();  
            this.Hide();
            memberPerformance.ShowDialog();
        }

        private void AddItems()
        {

            string query = "SELECT performanceid FROM performance join myUser on " +
                "performance.MemberId=Myuser.Id where myUser.UserName=@UserName";


            string UserName = SignIn.UserName;
            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Username", UserName);



            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();

            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("PerformanceId", typeof(int));
            AddColumnIfNotExists("MemberId", typeof(int));
            AddColumnIfNotExists("Date", typeof(DateTime));
            AddColumnIfNotExists("WorkoutDurationMinutes", typeof(int));
            AddColumnIfNotExists("CaloriesBurned", typeof(int));
            AddColumnIfNotExists("DistanceCoveredKm", typeof(int));
            AddColumnIfNotExists("HeartBeatAvg", typeof(int));
            int id = int.Parse(comboBox1.Text);
            
            List<Performance> myPerformance = new List<Performance>();

            myPerformance = ObjectHandler.GetMemberDL().GetPerformance(id);


            foreach (Performance performance in myPerformance)
            {
                dataTable.Rows.Add(performance.MyPerformanceId,performance.MyMemberId,performance.MyDate,performance.MyDuration,performance.MyCalories,performance.MyDistance,performance.MyHeartBeat);

            }

            dataGridView1.DataSource = dataTable;
        }

        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

        private void ViewPerformance_Load(object sender, EventArgs e)
        {

        }
    }
}
