﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class SelectSession : Form
    {

        private DataTable dataTable = new DataTable();  
        public SelectSession()
        {
            InitializeComponent();
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemberSession memberSession = new MemberSession();  
            this.Hide();
            memberSession.ShowDialog();
        }

        private void SelectSession_Load(object sender, EventArgs e)
        {

        }

        private void LoadData()
        {
            DataTable dataSource = (DataTable)dataGridView1.DataSource;
            if (dataSource != null)
            {
                dataSource.Rows.Clear();
            }
            AddColumnIfNotExists("SessionId", typeof(int));
            AddColumnIfNotExists("TrainerId", typeof(int));
            AddColumnIfNotExists("Date", typeof(DateTime));
            AddColumnIfNotExists("StartTime", typeof(TimeSpan));
            AddColumnIfNotExists("EndTime", typeof(TimeSpan));

            List<Session> sessions = new List<Session>();

            sessions = ObjectHandler.GetMemberDL().GetSessions();


            foreach (Session session in sessions)
            {
                dataTable.Rows.Add(session.MySessionId, session.MyTrainerId, session.Date, session.MyStartTime, session.MyEndTime);

            }

            dataGridView1.DataSource = dataTable;
        }
        private void AddColumnIfNotExists(string columnName, Type columnType)
        {
            if (!dataTable.Columns.Contains(columnName))
            {
                dataTable.Columns.Add(columnName, columnType);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells[0].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Id;
            string UserName = SignIn.UserName;

            if (textBox1.Text!=string.Empty)
            {
                Id = int.Parse(textBox1.Text);

                if (ObjectHandler.GetMemberDL().SelectSessions(Id, UserName))
                {
                    MessageBox.Show("Session Selected Successfully");
                }
                else
                {
                    MessageBox.Show("Session already Selected!");
                }
            }

            else
            {
                MessageBox.Show("Select a session!");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
