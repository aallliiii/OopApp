﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Admin;
using GYM_Management_System.Login;
using GYMLibrary.BL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class AddPerformance : Form
    {
        public AddPerformance()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemberPerformance memberPerformance = new MemberPerformance();
            this.Hide();
            memberPerformance.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string UserName = SignIn.UserName;

            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty && textBox3.Text != string.Empty && textBox4.Text != string.Empty)
            {
                int Minutes = int.Parse(textBox1.Text);
                int Calories = int.Parse(textBox2.Text);
                int Distance = int.Parse(textBox3.Text);
                int HeartBeat = int.Parse(textBox4.Text);
                Performance performance = new Performance(Minutes, Calories, Distance, HeartBeat);
                if (ObjectHandler.GetMemberDL().AddPerformance(UserName, performance))
                {
                    MessageBox.Show("Performance Added Successfully!");
                }
                else
                {
                    MessageBox.Show("Error adding performance");
                }
            }
            else
            {
                MessageBox.Show("Please fill the required fields");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
