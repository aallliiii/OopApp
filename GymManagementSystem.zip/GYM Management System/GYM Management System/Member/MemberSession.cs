﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_Management_System.Member
{
    public partial class MemberSession : Form
    {
        public MemberSession()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MemberMenu memberMenu = new MemberMenu();
            this.Hide();
            memberMenu.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SelectSession selectSession = new SelectSession();
            this.Hide();
            selectSession.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewSelectedSession viewSelectedSession = new ViewSelectedSession();    
            this.Hide();
            viewSelectedSession.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DeleteSelectedSession deleteSelectedSession = new DeleteSelectedSession();
            this.Hide();
            deleteSelectedSession.ShowDialog();
        }
    }
}
