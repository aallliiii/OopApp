﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Member
{
    public partial class DeletePerformance : Form
    {
        public DeletePerformance()
        {
            InitializeComponent();
            AddItems();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemberPerformance performance = new MemberPerformance();
            this.Hide();
            performance.ShowDialog();
        }

        private void AddItems()
        {

            string query = "SELECT performanceid FROM performance join myUser on " +
                "performance.MemberId=Myuser.Id where myUser.UserName=@UserName";


            string UserName = SignIn.UserName;
            SqlConnection connection = new SqlConnection(MyUserDL.ConnectionString);
            connection.Open();


            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Username", UserName);



            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();


            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetInt32(0)).ToString();
            }


            reader.Close();

            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text!=string.Empty)
            {
                int Id = int.Parse(comboBox1.Text); 

                if (ObjectHandler.GetMemberDL().DeletePerformance(Id))
                {
                    MessageBox.Show("Performance Deleted Successfully!");
                }
                else
                {
                    MessageBox.Show("Error!");
                }
            }
            else
            {
                MessageBox.Show("Select a performance to Delete");
            }
        }
    }
}
