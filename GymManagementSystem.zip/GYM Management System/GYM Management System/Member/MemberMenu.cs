﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Login;

namespace GYM_Management_System.Member
{
    public partial class MemberMenu : Form
    {
        public MemberMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            this.Hide();
            signIn.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            this.Hide();
            signIn.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MemberWorkout memberWorkout = new MemberWorkout();
            this.Hide();
            memberWorkout.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MemberSession memberSession = new MemberSession();
            this.Hide();
            memberSession.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MemberPerformance memberPerformance = new MemberPerformance();
            this.Hide();
            memberPerformance.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Fees fees = new Fees();
            this.Hide(); 
            fees.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MemberSettings memberSettings = new MemberSettings();
            this.Hide();
            memberSettings.ShowDialog();
        }
    }
}
