﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYMLibrary.BL;
using GYMLibrary.DL;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Text.RegularExpressions;
using GYMLibrary.Utilities;


namespace GYM_Management_System.Login
{
    public partial class SignUp : Form
    {
        string MyEmail = "^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$";
        int LengthMax = 11;
        public SignUp()
        {
            InitializeComponent();
            AddItems();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string UserName;
            string Password;
            string FirstName;
            string LastName;
            string Email;
            string PhoneNumber;
            int Role;
            if (!Regex.IsMatch(textBox6.Text, MyEmail))
            {
                errorProvider1.SetError(this.textBox6, "Email Format is Incorrect");
            }
            else if (textBox5.Text.Length > LengthMax || textBox5.Text.Length < LengthMax)
            {
                errorProvider2.SetError(this.textBox5, "Contact Number is not Correct");
            }
            else
            {
                if (textBox1.Text != string.Empty && textBox2.Text != string.Empty && textBox3.Text != string.Empty && textBox4.Text != string.Empty && textBox5.Text != string.Empty && textBox6.Text != string.Empty && comboBox1.Text != string.Empty)
                {
                    UserName = textBox1.Text;
                    Password = textBox2.Text;
                    FirstName = textBox3.Text;
                    LastName = textBox4.Text;
                    PhoneNumber = textBox5.Text;
                    Email = textBox6.Text;

                    string Command = "select id from UserType where category=@category";
                    SqlConnection con = new SqlConnection(MyUserDL.ConnectionString);
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Command, con);
                    cmd.Parameters.AddWithValue("@category", comboBox1.Text);
                    Role = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    if (Role == 2)
                    {
                        MyTrainer SigningUp = new MyTrainer(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role);
                        if (ObjectHandler.GetSignInUp().IsUserNameValid(UserName))
                        {
                            if (ObjectHandler.GetSignInUp().SignUp(SigningUp))
                            {

                                MessageBox.Show("User Added Successfully!");
                            }
                            else
                            {
                                MessageBox.Show("Error while Signing Up");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Username already Exists!");
                        }
                    }

                    else if (Role == 1)
                    {
                        MyAdmin SigningUp = new MyAdmin(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role);

                        if (ObjectHandler.GetSignInUp().IsUserNameValid(UserName))
                        {
                            if (ObjectHandler.GetSignInUp().SignUp(SigningUp))

                            {

                                MessageBox.Show("User Added Successfully!");
                            }
                            else
                            {
                                MessageBox.Show("Error while Signing Up");
                            }
                        }

                        else
                        {
                            MessageBox.Show("UserName already Exists");

                        }
                    }




                }
            }
        }
        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void AddItems()
        {
            List<string> list = new List<string>();

            list = ObjectHandler.GetSignInUp().CategoryType();

            foreach (string category in list)
            {
                comboBox1.Items.Add(category);  
            }
            
        }

        private void textBox6_Leave(object sender, EventArgs e)
        {
            if (!Regex.IsMatch(textBox6.Text, MyEmail))
            {
                errorProvider1.SetError(this.textBox6, "Email Format is Incorrect");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsLetter(input) || input == 8 || input == 32)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char input;
            input = e.KeyChar;
            if (char.IsDigit(input) || input == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text.Length > LengthMax || textBox5.Text.Length < LengthMax)
            {
                errorProvider2.SetError(this.textBox5, "Contact Number is not Correct");
            }
            else
            {
                errorProvider2.Clear();
            }
        }
    }
}
