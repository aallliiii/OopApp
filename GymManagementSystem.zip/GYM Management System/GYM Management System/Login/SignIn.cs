﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GYM_Management_System.Admin;
using GYM_Management_System.Member;
using GYM_Management_System.Trainer;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace GYM_Management_System.Login
{
    public partial class SignIn : Form
    {

        public static string UserName;

        public static string Password;

        public static int ID;
        public SignIn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
           
            
            if (textBox1.Text!=string.Empty&&textBox2.Text!=string.Empty)
            {
                UserName = textBox1.Text;
                Password = textBox2.Text;

                MyUser myUser = new MyUser(UserName,Password);

                MyUser User = ObjectHandler.GetSignInUp().Login(myUser);
               
                if (User != null)
                {
                    if (ObjectHandler.GetMyUserDL().IsAdmin(User))
                    {
                        ID = 1;
                        AdminMenu adminMenu = new AdminMenu();
                        this.Hide();
                        adminMenu.ShowDialog();
                    }
                    else if (ObjectHandler.GetMyUserDL().IsTrainer(User))
                    {
                        ID = 2;
                        TrainerMenu trainerMenu = new TrainerMenu();
                        this.Hide();
                        trainerMenu.ShowDialog();
                    }
                    else if (ObjectHandler.GetMyUserDL().IsMember(User))
                    {
                        ID = 3;
                        MemberMenu memberMenu = new MemberMenu();
                        this.Hide();
                        memberMenu.ShowDialog();
                    }
                    
                }
                else
                {
                    MessageBox.Show("Invalid User!");
                }
            }
            else
            {
                MessageBox.Show("Input Values First!");
            } 
        }

        private void SignIn_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
