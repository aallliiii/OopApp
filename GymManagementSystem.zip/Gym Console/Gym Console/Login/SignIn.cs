﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gym_Console.Admin;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;

namespace Gym_Console.Login
{
    public class SignIn
    {
        public static string UserName;
        public static string Password;
        public static string SignInFunction()
        {
            Console.Clear();
            MainMenu.Header();
            string Role = "Invalid";
            Console.WriteLine("Enter UserName");
            UserName = Console.ReadLine();
            Console.WriteLine("Enter Password");
            Password = Console.ReadLine();
            if (UserName != null && Password != null)
            {


                MyUser myUser = new MyUser(UserName, Password);

                MyUser User = ObjectHandler.GetSignInUp().Login(myUser);

                if (User != null)
                {
                    if (ObjectHandler.GetMyUserDL().IsAdmin(User))
                    {

                        Role = "Admin";
                    }
                    else if (ObjectHandler.GetMyUserDL().IsTrainer(User))
                    {

                        Console.WriteLine("I M Trainer");
                        Role = "Trainer";
                        Console.ReadKey();
                    }
                    else if (ObjectHandler.GetMyUserDL().IsMember(User))
                    {

                        Console.WriteLine("I M Member");
                        Role = "Member";
                        Console.ReadKey();
                    }

                }
                else
                {
                    Console.WriteLine("Invalid User");
                    Role = "Invalid";
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine("Input Data");

                Console.ReadKey();
            }

            return Role;
        }
        
    }
}
