﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;
using GYMLibrary.DL;
using System.Data.SqlClient;
using System.Data;
using GYMLibrary.Utilities;
using System.Text.RegularExpressions;
using System.Runtime.Remoting.Messaging;

namespace Gym_Console.Login
{
    internal class SignUp
    {
        public static void SignUpFunction()
        {

            string UserName;
            string Password;
            string FirstName;
            string LastName;
            string Email;
            string PhoneNumber;
            string Category;
            int Role;
            Console.Clear();
            MainMenu.Header();
            Console.WriteLine("Enter Username: ");
            UserName = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            Password = Console.ReadLine();
            Console.WriteLine("Enter First Name: ");
            FirstName = Console.ReadLine();
            Console.WriteLine("Enter Last Name: ");
            LastName = Console.ReadLine();
            if (Regex.IsMatch(FirstName, @"\d") || Regex.IsMatch(LastName, @"\d"))
            {
                Console.WriteLine("First and last name must not contain digits.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter Email: ");
            Email = Console.ReadLine();
            if (!Regex.IsMatch(Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
            {
                Console.WriteLine("Invalid email format.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter PhoneNumber: ");
            PhoneNumber = Console.ReadLine();
            if (!Regex.IsMatch(PhoneNumber, @"^\d{11}$"))
            {
                Console.WriteLine("Phone number must be 11 digits.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter role (Admin or Trainer): ");
            Category = Console.ReadLine().ToLower();


            if (Category != "admin" && Category != "trainer")
            {
                Console.WriteLine("Invalid role. Role must be either 'Admin' or 'Trainer'.");
                Console.ReadKey();
                return;
            }

            string Command = "select id from UserType where category=@category";
            SqlConnection con = new SqlConnection(MyUserDL.ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Command, con);
            cmd.Parameters.AddWithValue("@category", Category);
            Role = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();

            MyUser SigningUp = new MyUser(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role);
            if (ObjectHandler.GetMyUserDL().IsUserNameValid(UserName))
            {
                if (ObjectHandler.GetSignInUp().SignUp(SigningUp))
                {

                    Console.WriteLine("User Added Successfully!");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Error While Signing Up");
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine("Username already Exists");
                Console.ReadKey();

            }

        }

    }
}
