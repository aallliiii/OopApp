﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym_Console.Login
{
    internal class MainMenu
    {
        public static int DisplayMainMenu ()
        {
            int Option = 0;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Header();
                Console.SetCursorPosition(70, 30);
                Console.WriteLine("Press 1 to SignIn");
                Console.SetCursorPosition(70, 32);
                Console.WriteLine("Press 2 to SignUp");
                Console.SetCursorPosition(70, 34);
                Console.WriteLine("Press 3 to Exit");
                Console.SetCursorPosition(90, 34);
                bool isValidOption = int.TryParse(Console.ReadLine(), out Option);
                if (!isValidOption || Option < 1 || Option > 3)
                {
                    Console.WriteLine("Invalid option. Press any key to try again...");
                    Console.ReadKey();
                }
            } while (Option < 1 || Option > 3);

            return Option;
        }

        public static void Header ()
        {
            Console.WriteLine("  /$$$$$$  /$$                                     /$$   /$$                 /$$$$$$$$ /$$   /$$                                                   /$$$$$$                         ");
            Console.WriteLine(" /$$__  $$| $$                                    | $$  | $$                | $$_____/|__/  | $$                                                  /$$__  $$                        ");
            Console.WriteLine("| $$  \\__/| $$$$$$$   /$$$$$$   /$$$$$$   /$$$$$$ | $$  | $$  /$$$$$$       | $$       /$$ /$$$$$$   /$$$$$$$   /$$$$$$   /$$$$$$$ /$$$$$$$      | $$  \\__/ /$$   /$$ /$$$$$$/$$$$ ");
            Console.WriteLine("|  $$$$$$ | $$__  $$ |____  $$ /$$__  $$ /$$__  $$| $$  | $$ /$$__  $$      | $$$$$   | $$|_  $$_/  | $$__  $$ /$$__  $$ /$$_____//$$_____/      | $$ /$$$$| $$  | $$| $$_  $$_  $$");
            Console.WriteLine(" \\____  $$| $$  \\ $$  /$$$$$$$| $$  \\ $$| $$$$$$$$| $$  | $$| $$  \\ $$      | $$__/   | $$  | $$    | $$  \\ $$| $$$$$$$$|  $$$$$$|  $$$$$$       | $$|_  $$| $$  | $$| $$ \\ $$ \\ $$");
            Console.WriteLine(" /$$  \\ $$| $$  | $$ /$$__  $$| $$  | $$| $$_____/| $$  | $$| $$  | $$      | $$      | $$  | $$ /$$| $$  | $$| $$_____/ \\____  $$\\____  $$      | $$  \\ $$| $$  | $$| $$ | $$ | $$");
            Console.WriteLine("|  $$$$$$/| $$  | $$|  $$$$$$$| $$$$$$$/|  $$$$$$$|  $$$$$$/| $$$$$$$/      | $$      | $$  |  $$$$/| $$  | $$|  $$$$$$$ /$$$$$$$//$$$$$$$/      |  $$$$$$/|  $$$$$$$| $$ | $$ | $$");
            Console.WriteLine(" \\______/ |__/  |__/ \\_______/| $$____/  \\_______/ \\______/ | $$____/       |__/      |__/   \\___/  |__/  |__/ \\_______/|_______/|_______/        \\______/  \\____  $$|__/ |__/ |__/");
            Console.WriteLine("                              | $$                          | $$                                                                                            /$$  | $$              ");
            Console.WriteLine("                              | $$                          | $$                                                                                           |  $$$$$$/              ");
            Console.WriteLine("                              |__/                          |__/                                                                                            \\______/               ");

        }
    }
}
