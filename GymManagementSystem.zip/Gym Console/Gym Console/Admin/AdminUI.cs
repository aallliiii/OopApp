﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GYMLibrary.BL;
using GYMLibrary.DL;
using GYMLibrary.Utilities;
using System.Globalization;
using System.Net.Http.Headers;
using Gym_Console.Login;
using System.Text.RegularExpressions;
using System.Runtime.Remoting.Messaging;

namespace Gym_Console.Admin
{
    internal class AdminUI
    {
        public static int AdminMenu()
        {
            int Option;

            do
            {
                Console.Clear();
                MainMenu.Header();
                Console.WriteLine("Press 1 to Manage Members");
                Console.WriteLine("Press 2 to Manage Employees");
                Console.WriteLine("Press 3 to Delete Trainer");
                Console.WriteLine("Press 4 to View All Users");
                Console.WriteLine("Press 5 to go to Settings");
                Console.WriteLine("Press 6 to Exit");

                if (!int.TryParse(Console.ReadLine(), out Option) || Option < 1 || Option > 6)
                {
                    Console.WriteLine("Invalid option. Please enter a number between 1 and 6.");
                    Console.WriteLine("Press any key to try again...");
                    Console.ReadKey();
                }
                else
                {
                    break;
                }
            } while (true);

            return Option;
        }

        public static int ManageMembers()
        {
            int Option;

            do
            {
                Console.Clear();
                MainMenu.Header();
                Console.WriteLine("Press 1 to Add Members");
                Console.WriteLine("Press 2 to Delete Members");
                Console.WriteLine("Press 3 to Update Members");
                Console.WriteLine("Press 4 to View Member");
                Console.WriteLine("Press 5 to View Fees Payment");

                if (!int.TryParse(Console.ReadLine(), out Option) || Option < 1 || Option > 5)
                {
                    Console.WriteLine("Invalid option. Please enter a number between 1 and 5.");
                    Console.WriteLine("Press any key to try again...");
                    Console.ReadKey();
                }
                else
                {
                    break;
                }
            } while (true);

            return Option;
        }


        public static void AddMembers()
        {
            string UserName;
            string Password;
            string FirstName;
            string LastName;
            string Email;
            string PhoneNumber;
            int Role = 3;
            Console.Clear();
            MainMenu.Header();
            Console.WriteLine("Enter Username: ");
            UserName = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            Password = Console.ReadLine();
            Console.WriteLine("Enter First Name: ");
            FirstName = Console.ReadLine();
            Console.WriteLine("Enter Last Name: ");
            LastName = Console.ReadLine();
            if (Regex.IsMatch(FirstName, @"\d") || Regex.IsMatch(LastName, @"\d"))
            {
                Console.WriteLine("First and last name must not contain digits.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter Email: ");
            Email = Console.ReadLine();
            if (!Regex.IsMatch(Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
            {
                Console.WriteLine("Invalid email format.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter PhoneNumber: ");
            PhoneNumber = Console.ReadLine();
            if (!Regex.IsMatch(PhoneNumber, @"^\d{11}$"))
            {
                Console.WriteLine("Phone number must be 11 digits.");
                Console.ReadKey();
                return;
            }



            MyUser SigningUp = new MyUser(UserName, Password, FirstName, LastName, PhoneNumber, Email, Role);
            if (ObjectHandler.GetMyUserDL().IsUserNameValid(UserName))
            {
                if (ObjectHandler.GetSignInUp().SignUp(SigningUp))
                {

                    Console.WriteLine("Member Added Successfully!");
                }
                else
                {
                    Console.WriteLine("Error While Adding Member");
                }
            }
            else
            {
                Console.WriteLine("Username already Exists");

            }
            Console.ReadKey();
        }

        public static void DeleteMembers()
        {
            Console.Clear();
            MainMenu.Header();
            string Username;
            Console.WriteLine("Enter Username of member you want to delete");
            Username = Console.ReadLine();

            if (ObjectHandler.ManageMembers().CheckMemberUsername(Username))
            {
                ObjectHandler.ManageMembers().DeleteMember(Username);
                Console.WriteLine("Member Deleted Successfully!");
            }
            else
            {
                Console.WriteLine("Member does not exist!");
            }
            Console.ReadKey();
        }

        public static void ViewMembers()
        {
            Console.Clear();
            MainMenu.Header();
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            List<MyMember> myMembers = ObjectHandler.ManageMembers().ViewMember();

            // Header
            Console.WriteLine($"{"Username",-20} {"Password",-20} {"First Name",-20} {"Last Name",-20} {"Phone Number",-15} {"Email",-30}");

            // Divider
            Console.WriteLine(new string('-', 125));

            // Data
            foreach (MyUser user in myMembers)
            {
                Console.WriteLine($"{user.MyUserName,-20} {user.MyPassword,-20} {user.MyFirstName,-20} {user.MyLastName,-20} {user.MyPhoneNumber,-15} {user.MyEmail,-30}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.ReadKey();
        }

        public static void UpdateMembers()
        {
            Console.Clear();
            MainMenu.Header();
            Console.WriteLine("Enter Old Username: ");
            string OldUsername = Console.ReadLine();

            if (ObjectHandler.ManageMembers().CheckMemberUsername(OldUsername))
            {
                Console.WriteLine("Enter New Username: ");
                string NewUsername = Console.ReadLine();
                


                    Console.WriteLine("Enter New Password: ");
                    string Password = Console.ReadLine();
                    Console.WriteLine("Enter New First Name: ");
                    string NewFirstName = Console.ReadLine();
                    Console.WriteLine("Enter New Last Name: ");
                    string NewLastName = Console.ReadLine();
                    if (Regex.IsMatch(NewFirstName, @"\d") || Regex.IsMatch(NewLastName, @"\d"))
                    {
                        Console.WriteLine("First and last name must not contain digits.");
                        Console.ReadKey();
                        return;
                    }
                    Console.WriteLine("Enter New Phone Number: ");
                    string NewPhoneNumber = Console.ReadLine();
                    if (!Regex.IsMatch(NewPhoneNumber, @"^\d{11}$"))
                    {
                        Console.WriteLine("Phone number must be 11 digits.");
                        Console.ReadKey();
                        return;
                    }
                    Console.WriteLine("Enter New Email: ");
                    string Email = Console.ReadLine();
                    if (!Regex.IsMatch(Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
                    {
                        Console.WriteLine("Invalid email format.");
                        Console.ReadKey();
                        return;
                    }
                    MyMember myMember = new MyMember(NewUsername, Password, NewFirstName, NewLastName, NewPhoneNumber, Email);
                    if (ObjectHandler.ManageMembers().UpdateMember(OldUsername, myMember))
                    {
                        Console.WriteLine("Member Updated Successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Error updating member");
                    }
                
            }
            else
            {
                Console.WriteLine("Member not Found!");
            }

            Console.ReadKey();
        }

        public static int ManageEmployees()
        {
            int Option;

            do
            {
                Console.Clear();
                MainMenu.Header();
                Console.WriteLine("Press 1 to Add Employees");
                Console.WriteLine("Press 2 to View Employees");
                Console.WriteLine("Press 3 to Delete Employees");
                Console.WriteLine("Press 4 to Update Employees");
                Console.WriteLine("Press 5 to Transfer Salary");

                if (!int.TryParse(Console.ReadLine(), out Option) || Option < 1 || Option > 5)
                {
                    Console.WriteLine("Invalid option. Please enter a number between 1 and 5.");
                    Console.WriteLine("Press any key to try again...");
                    Console.ReadKey();
                }
                else
                {
                    break;
                }
            } while (true);

            return Option;
        }


        public static void AddEmployees()
        {
            Console.Clear();
            MainMenu.Header();
            Console.WriteLine("Enter Employee First Name: ");
            string FirstName = Console.ReadLine();
            Console.WriteLine("Enter Employee Last Name: ");
            string LastName = Console.ReadLine();
            if (Regex.IsMatch(FirstName, @"\d") || Regex.IsMatch(LastName, @"\d"))
            {
                Console.WriteLine("First and last name must not contain digits.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter Employee Designation: ");
            string Designation = Console.ReadLine();
            Console.WriteLine("Enter Employee Salary: ");
            string Salary = Console.ReadLine();

            Employees employees = new Employees(FirstName, LastName, Designation, Salary);

            if (ObjectHandler.GetAdminDL().AddEmployees(employees))
            {
                Console.WriteLine("Employee Added Successfully!");
            }
            else
            {
                Console.WriteLine("Error adding Employee");
            }
            Console.ReadKey();


        }
        public static void ViewEmployees()
        {
            Console.Clear();
            MainMenu.Header();
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            List<Employees> employees = ObjectHandler.GetAdminDL().ViewEmployee();

            // Header
            Console.WriteLine($"{"First Name",-20} {"Last Name",-20} {"Designation",-20} {"Salary",-15}");

            // Divider
            Console.WriteLine(new string('-', 75));

            // Data
            foreach (Employees e in employees)
            {
                Console.WriteLine($"{e.MyFirstName,-20} {e.MyLastName,-20} {e.MyDesignation,-20} {e.MySalary,-15}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.ReadKey();
        }


        public static void DeleteEmployee()
        {
            int Id;

            do
            {
                Console.Clear();
                MainMenu.Header();
                Console.WriteLine("Enter Employee id to Delete Employee: ");
                if (!int.TryParse(Console.ReadLine(), out Id))
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                    Console.WriteLine("Press any key to try again...");
                    Console.ReadKey();
                }
                else
                {
                    break;
                }
            } while (true);

            if (ObjectHandler.GetAdminDL().CheckEmployeeId(Id))
            {
                if (ObjectHandler.GetAdminDL().DeleteEmployees(Id))
                {
                    Console.WriteLine("Employee Deleted Successfully!");
                }
                else
                {
                    Console.WriteLine("Error Deleting Employee!");
                }
            }
            else
            {
                Console.WriteLine("Employee not found!");
            }
            Console.ReadKey();
        }


        public static void UpdateEmployee()
        {
            int id;

            do
            {
                Console.Clear();
                MainMenu.Header();
                Console.WriteLine("Enter Employee id you want to update: ");
                if (!int.TryParse(Console.ReadLine(), out id))
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                    Console.WriteLine("Press any key to try again...");
                    Console.ReadKey();
                }
                else
                {
                    break;
                }
            } while (true);

            if (ObjectHandler.GetAdminDL().CheckEmployeeId(id))
            {
                Console.WriteLine("Enter New First Name");
                string FirstName = Console.ReadLine();
                Console.WriteLine("Enter New Last Name");
                string LastName = Console.ReadLine();
                if (Regex.IsMatch(FirstName, @"\d") || Regex.IsMatch(LastName, @"\d"))
                {
                    Console.WriteLine("First and last name must not contain digits.");
                    Console.ReadKey();
                    return;
                }
                Console.WriteLine("Enter New Designation");
                string Designation = Console.ReadLine();
                Console.WriteLine("Enter new Salary");
                string Salary = Console.ReadLine();

                Employees employees = new Employees(id, FirstName, LastName, Designation, Salary);

                if (ObjectHandler.GetAdminDL().UpdateEmployees(employees))
                {
                    Console.WriteLine("Employee Updated Successfully");
                }
                else
                {
                    Console.WriteLine("Error Updating Employee!");
                }
            }
            else
            {
                Console.WriteLine("Employee not found!");
            }
            Console.ReadKey();
        }


        public static void TransferSalary()
        {
            int id;

            do
            {
                Console.Clear();
                MainMenu.Header();
                Console.WriteLine("Enter Employee Id to Transfer Salary: ");
                if (!int.TryParse(Console.ReadLine(), out id))
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                    Console.WriteLine("Press any key to try again...");
                    Console.ReadKey();
                }
                else
                {
                    break;
                }
            } while (true);

            if (ObjectHandler.GetAdminDL().CheckEmployeeId(id))
            {
                string PaymentMethod = null;
                Console.WriteLine("Choose Payment Method:");
                Console.WriteLine("Press 1 for Online Transfer: ");
                Console.WriteLine("Press 2 for Cash Payment: ");
                int select = int.Parse(Console.ReadLine());
                if (select == 1)
                {
                    PaymentMethod = "Online Transfer";
                }
                else if (select == 2)
                {
                    PaymentMethod = "Cash";
                }
                if (select == 1 || select == 2)
                {
                    if (ObjectHandler.GetAdminDL().AddSalary(id, PaymentMethod))
                    {
                        Console.WriteLine("Salary Transfered Successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Error!");
                    }
                }
                else
                {
                    Console.WriteLine("Wrong Payment Method Selected!");
                }


            }
            else
            {
                Console.WriteLine("Employee not found!");
            }
            Console.ReadKey();
        }

        public static void DeleteTrainer()
        {
            Console.Clear();
            MainMenu.Header();
            Console.WriteLine("Enter Trainer Username: ");
            string Username = Console.ReadLine();
            if (ObjectHandler.GetAdminDL().TrainerCheck(Username))
            {
                if (ObjectHandler.GetAdminDL().DeleteTrainer(Username))
                {
                    Console.WriteLine("Trainer Deleted Successfully!");
                }
                else
                {
                    Console.WriteLine("Error Deleting trainer!");
                }
            }
            else
            {
                Console.WriteLine("Trainer not Found!");
            }
            Console.ReadKey();
        }

        public static void ViewAllUsers()
        {
            Console.Clear();
            MainMenu.Header();
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            List<MyUser> users = ObjectHandler.GetAdminDL().GetMyUsers();


            int usernameWidth = 20;
            int passwordWidth = 20;
            int firstNameWidth = 20;
            int lastNameWidth = 20;
            int phoneNumberWidth = 15;
            int emailWidth = 30;
            int roleWidth = 10;

            // Header
            Console.WriteLine($"{"Username",-20} {"Password",-20} {"First Name",-20} {"Last Name",-20} {"Phone Number",-15} {"Email",-30} {"Role",-10}");

            // Divider
            Console.WriteLine(new string('-', usernameWidth + passwordWidth + firstNameWidth + lastNameWidth + phoneNumberWidth + emailWidth + roleWidth));

            // Data
            foreach (MyUser user in users)
            {
                Console.WriteLine($"{user.MyUserName,-20} {user.MyPassword,-20} {user.MyFirstName,-20} {user.MyLastName,-20} {user.MyPhoneNumber,-15} {user.MyEmail,-30} {user.MyRole,-10}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.ReadKey();
        }

        public static void ViewMemberFees()
        {
            Console.Clear();
            MainMenu.Header();
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            List<Payments> payments = ObjectHandler.GetAdminDL().GetMyPayments();

            // Header
            Console.WriteLine($"{"Fee ID",-10} {"Member ID",-10} {"Number of Months",-20} {"Amount",-15} {"Payment Method",-20} {"Date",-20}");

            // Divider
            Console.WriteLine(new string('-', 95));

            // Data
            foreach (Payments p in payments)
            {
                Console.WriteLine($"{p.MyFeesId,-10} {p.MyMemberId,-10} {p.MyMonths,-20} {p.MyAmount,-15} {p.MyPaymentMethod,-20} {p.MyDate,-20}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.ReadKey();
        }


        public static void Settings()
        {
            Console.Clear();
            MainMenu.Header();
            Console.WriteLine("Enter New Username:");
            string NewUserName = Console.ReadLine();
            Console.WriteLine("Enter New Password: ");
            string Password = Console.ReadLine();
            Console.WriteLine("Enter New First Name: ");
            string FirstName = Console.ReadLine();
            Console.WriteLine("Enter New Last Name: ");
            string LastName = Console.ReadLine();
            if (Regex.IsMatch(FirstName, @"\d") || Regex.IsMatch(LastName, @"\d"))
            {
                Console.WriteLine("First and last name must not contain digits.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter New Phone Number: ");
            string PhoneNumber = Console.ReadLine();
            if (!Regex.IsMatch(PhoneNumber, @"^\d{11}$"))
            {
                Console.WriteLine("Phone number must be 11 digits.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Enter New Email: ");
            string Email = Console.ReadLine();
            if (!Regex.IsMatch(Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
            {
                Console.WriteLine("Invalid email format.");
                Console.ReadKey();
                return;
            }
            MyUser myUser = new MyUser(NewUserName, Password, FirstName, LastName, PhoneNumber, Email);

            if (ObjectHandler.GetAdminDL().MyUpdate(SignIn.UserName, myUser))
            {
                Console.WriteLine("Updated Successfully!");
            }
            else
            {
                Console.WriteLine("Error!");
            }

            Console.ReadKey();
        }
    }
}
