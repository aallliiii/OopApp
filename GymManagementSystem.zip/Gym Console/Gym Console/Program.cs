﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gym_Console.Admin;
using Gym_Console.Login;
using GYMLibrary.DL;
using GYMLibrary.Utilities;


namespace Gym_Console
{
    internal class Program
    {
        static void Main(string[] args)
        {

            while (true)
            {
                int Option = MainMenu.DisplayMainMenu();
                Console.Clear();
                if (Option == 1)
                {
                    string role = SignIn.SignInFunction();
                    if (role == "Admin")
                    {
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                        while (true)
                        {
                            int AdminOption = AdminUI.AdminMenu();
                            if (AdminOption == 1)
                            {
                                int ManageMemberOption = AdminUI.ManageMembers();

                                if (ManageMemberOption == 1)
                                {
                                    AdminUI.AddMembers();
                                }
                                else if (ManageMemberOption == 2)
                                {
                                    AdminUI.DeleteMembers();
                                }
                                else if (ManageMemberOption == 3)
                                {
                                    AdminUI.UpdateMembers();
                                }
                                else if (ManageMemberOption == 4)
                                {
                                    AdminUI.ViewMembers();
                                }
                                else if (ManageMemberOption == 5)
                                {
                                    AdminUI.ViewMemberFees();
                                }
                            }
                            else if (AdminOption == 2)
                            {
                                int ManageEmployeeOption = AdminUI.ManageEmployees();
                                if (ManageEmployeeOption == 1)
                                {
                                    AdminUI.AddEmployees();
                                }
                                else if (ManageEmployeeOption == 2)
                                {
                                    AdminUI.ViewEmployees();
                                }
                                else if (ManageEmployeeOption == 3)
                                {
                                    AdminUI.DeleteEmployee();
                                }
                                else if (ManageEmployeeOption == 4)
                                {
                                    AdminUI.UpdateEmployee();
                                }
                                else if (ManageEmployeeOption == 5)
                                {
                                    AdminUI.TransferSalary();
                                }
                            }
                            else if (AdminOption == 3)
                            {
                                AdminUI.DeleteTrainer();
                            }
                            else if (AdminOption == 4)
                            {
                                AdminUI.ViewAllUsers();
                            }
                            else if (AdminOption == 5)
                            {
                                AdminUI.Settings();
                            }
                            else if (AdminOption == 6)
                            {
                                break;
                            }

                        }
                    }
                }
                else if (Option == 2)
                {
                    SignUp.SignUpFunction();

                }
                else if (Option == 3)
                {
                    break;
                }

                
            }
        }

    }
}
